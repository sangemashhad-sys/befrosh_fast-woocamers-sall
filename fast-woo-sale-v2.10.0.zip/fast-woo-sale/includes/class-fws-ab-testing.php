<?php
/**
 * Class FWS_AB_Testing
 * موتور A/B تست ویجت‌ها — نسخه ۲.۹
 *
 * مأموریت: مقایسه واقعی دو نسخه از عنوان/رنگ یک ویجت روی دو گروه تصادفی و پایدار
 * از بازدیدکنندگان، و اعلام برنده بر اساس معناداری آماری (z-test دو نسبت).
 *
 * اصول کنترل (قانون طلایی نسخه ۲.۹):
 *  ۱) تست فقط روی ویجتی اجرا می‌شود که از تنظیمات نسخه ۲.۸ فعال باشد؛ ویجت خاموش = تست هم بی‌اثر
 *  ۲) هر ویجت در هر لحظه حداکثر یک تست فعال دارد
 *  ۳) نسخه A همیشه «کنترل» است (ظاهر فعلی مدیر)؛ فقط B می‌تواند عنوان/رنگ جایگزین داشته باشد
 *  ۴) اختصاص نسخه در سشن ووکامرس ذخیره می‌شود تا کاربر در کل بازدیدش نسخه ثابت ببیند
 *  ۵) پس از اعلام برنده، نسخه برنده تا حذف/بازنشانی تست قفل می‌شود (تغییر ناگهانی ظاهر ندارد)
 *  ۶) تست متوقف‌شده هیچ اثری روی ظاهر ندارد
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWS_AB_Testing {

    const OPTION_KEY = 'fws_ab_tests';

    /** حداکثر تعداد تست‌های نگهداری‌شده (فعال + خاتمه‌یافته) */
    const MAX_TESTS = 12;

    /** حداقل نمایش هر نسخه برای اعتبار اعلام برنده */
    const MIN_IMPRESSIONS = 100;

    /** آستانه معناداری آماری (p-value) */
    const SIGNIFICANCE = 0.05;

    /**
     * فهرست ویجت‌های قابل تست (شناسه کوتاه = برچسب فارسی)
     * شورت‌کد و مودال خروج عمداً خارج هستند؛ شورت‌کد انتخاب صریح مدیر است و
     * مودال خروج مسیر نمایش متفاوتی دارد.
     * @return array
     */
    public static function testable_widgets() {
        return array(
            'product'  => 'باکس پکیج هوشمند (صفحه محصول)',
            'cart'     => 'پیشنهادات مکمل (سبد خرید)',
            'thankyou' => 'آپسل یک‌کلیکی (صفحه تشکر)',
            'shipping' => 'نوار ارسال رایگان',
            'account'  => 'پیش‌بینی خرید بعدی (حساب کاربری)',
            'search'   => 'بنر پیشنهاد (نتایج جستجو)',
        );
    }

    /* ───────────────────────── ذخیره‌سازی تست‌ها ───────────────────────── */

    /**
     * @return array
     */
    public static function get_tests() {
        $tests = get_option(self::OPTION_KEY, array());
        return is_array($tests) ? $tests : array();
    }

    /**
     * @param array $tests
     * @return bool
     */
    public static function save_tests($tests) {
        return update_option(self::OPTION_KEY, array_values($tests), false);
    }

    /**
     * تست فعال (running) برای یک ویجت — حداکثر یکی
     * @param string $widget_slug
     * @return array|null
     */
    public static function running_test_for($widget_slug) {
        static $cache = array();
        $widget_slug = sanitize_key((string) $widget_slug);
        if (!array_key_exists($widget_slug, $cache)) {
            $found = null;
            foreach (self::get_tests() as $test) {
                if ('running' === $test['status'] && $widget_slug === $test['widget']) {
                    $found = $test;
                    break;
                }
            }
            $cache[$widget_slug] = $found;
        }
        return $cache[$widget_slug];
    }

    /**
     * تست خاتمه‌یافته با برنده قفل‌شده برای یک ویجت
     * @param string $widget_slug
     * @return array|null
     */
    private static function concluded_test_for($widget_slug) {
        foreach (self::get_tests() as $test) {
            if ($widget_slug === $test['widget'] && in_array($test['status'], array('winner_a', 'winner_b'), true)) {
                return $test;
            }
        }
        return null;
    }

    /* ───────────────────────── اختصاص نسخه به بازدیدکننده ───────────────────────── */

    /**
     * نسخه موثر برای این بازدیدکننده روی این ویجت: '' | 'A' | 'B'
     * برنده قفل‌شده همیشه برمی‌گردد؛ تست running بر اساس سشن؛ بقیه خالی
     *
     * @param string $widget_slug
     * @return string
     */
    public static function effective_variant($widget_slug) {
        $widget_slug = sanitize_key((string) $widget_slug);

        // ۱) برنده قفل‌شده
        $concluded = self::concluded_test_for($widget_slug);
        if ($concluded) {
            return ('winner_b' === $concluded['status']) ? 'B' : 'A';
        }

        // ۲) تست در حال اجرا
        $test = self::running_test_for($widget_slug);
        if (!$test) {
            return '';
        }
        return self::session_assignment($test);
    }

    /**
     * اختصاص پایدار نسخه در سشن ووکامرس (سقوط به تخصیص قطعی هش‌محور)
     * @param array $test
     * @return string 'A'|'B'
     */
    private static function session_assignment($test) {
        if (!function_exists('WC') || !WC()->session) {
            return 'A'; // بدون سشن (کش سرور و...) همیشه کنترل — رفتار امن
        }
        $map = WC()->session->get('fws_ab_assignments');
        if (!is_array($map)) {
            $map = array();
        }
        if (isset($map[$test['id']]) && in_array($map[$test['id']], array('A', 'B'), true)) {
            return $map[$test['id']];
        }
        $split   = max(5, min(50, (int) $test['split']));
        $variant = ((crc32($test['id'] . '|' . FWS_Tracker::session_hash()) % 100) < $split) ? 'B' : 'A';
        $map[$test['id']] = $variant;
        WC()->session->set('fws_ab_assignments', $map);
        return $variant;
    }

    /* ───────────────────────── اعمال نسخه روی ظاهر ───────────────────────── */

    /**
     * عنوان موثر ویجت — جایگزین امن برای رشته‌های ثابت رندرها
     * نسخه A (کنترل) همیشه عنوان پیش‌فرض/ذخیره‌شده مدیر را برمی‌گرداند
     *
     * @param string $widget_slug
     * @param string $default_title
     * @return string
     */
    public static function widget_title($widget_slug, $default_title) {
        $variant = self::effective_variant($widget_slug);
        if ('' === $variant) {
            return $default_title;
        }

        if ('A' === $variant) {
            $test = self::running_test_for($widget_slug);
            $title_a = ($test && !empty($test['title_a'])) ? $test['title_a'] : $default_title;
            return (string) $title_a;
        }

        // نسخه B
        $test = self::concluded_test_for($widget_slug);
        if (!$test) {
            $test = self::running_test_for($widget_slug);
        }
        if ($test && !empty($test['title_b'])) {
            return (string) $test['title_b'];
        }
        return $default_title;
    }

    /**
     * اعمال رنگ تاکیدی نسخه B از طریق فیلتر متغیرهای CSS نسخه ۲.۸
     * هوک: fws_style_variables
     *
     * @param array $vars
     * @return array
     */
    public static function filter_style_variables($vars) {
        foreach (self::testable_widgets() as $slug => $label) {
            $variant = self::effective_variant($slug);
            if ('B' !== $variant) {
                continue;
            }
            $test = self::concluded_test_for($slug);
            if (!$test) {
                $test = self::running_test_for($slug);
            }
            if ($test && !empty($test['color_b']) && preg_match('/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $test['color_b'])) {
                $accent = strtolower($test['color_b']);
                if (4 === strlen($accent)) {
                    $accent = '#' . $accent[1] . $accent[1] . $accent[2] . $accent[2] . $accent[3] . $accent[3];
                }
                $vars['--fws-accent']       = $accent;
                $vars['--fws-accent-hover'] = FWS_Style_Manager::darken_hex($accent, 12);
            }
        }
        return $vars;
    }

    /* ───────────────────────── آمار و معناداری ───────────────────────── */

    /**
     * آمار زنده یک تست از جدول رخدادها (از لحظه شروع تست)
     * @param array $test
     * @return array ['A'=>['impression'=>..,'add_to_cart'=>..,'purchase'=>..,'revenue'=>..], 'B'=>[...]]
     */
    public static function test_stats($test) {
        $blank = array('impression' => 0, 'add_to_cart' => 0, 'purchase' => 0, 'revenue' => 0.0);
        $out = array('A' => $blank, 'B' => $blank);

        global $wpdb;
        $table = $wpdb->prefix . FWS_Tracker::TABLE_EVENT;
        $exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
        if (!$exists) {
            return $out;
        }

        $since = gmdate('Y-m-d H:i:s', (int) $test['created']);
        $rows  = $wpdb->get_results($wpdb->prepare(
            "SELECT variant, event_type, COUNT(*) AS cnt, SUM(revenue) AS revenue
             FROM {$table}
             WHERE widget = %s AND event_time >= %s AND variant IN ('A','B')
             GROUP BY variant, event_type",
            sanitize_key($test['widget']), $since
        ), ARRAY_A);

        foreach ((array) $rows as $row) {
            $v = ('B' === $row['variant']) ? 'B' : 'A';
            $t = (string) $row['event_type'];
            if (array_key_exists($t, $out[$v])) {
                $out[$v][$t] += (int) $row['cnt'];
            }
            $out[$v]['revenue'] += (float) $row['revenue'];
        }
        return $out;
    }

    /**
     * بررسی خودکار همه تست‌های running و قفل برنده در صورت معناداری
     * (کرون روزانه + دکمه دستی ادمین)
     * @return array فهرست تست‌هایی که همین لحظه برنده‌شان اعلام شد
     */
    public static function check_conclusions() {
        $concluded_now = array();
        $tests = self::get_tests();
        $changed = false;

        foreach ($tests as $i => $test) {
            if ('running' !== $test['status']) {
                continue;
            }
            $stats = self::test_stats($test);
            $impA  = $stats['A']['impression'];
            $impB  = $stats['B']['impression'];

            if ($impA < self::MIN_IMPRESSIONS || $impB < self::MIN_IMPRESSIONS) {
                continue; // هنوز داده کافی نیست
            }
            $convA = $stats['A']['add_to_cart'];
            $convB = $stats['B']['add_to_cart'];
            if (0 === ($convA + $convB)) {
                continue; // هیچ تبدیلی — معنادار نیست
            }

            $p_value = self::two_proportion_p_value($convA, $impA, $convB, $impB);
            if (null === $p_value || $p_value >= self::SIGNIFICANCE) {
                continue;
            }

            $winner          = ($convB > $convA) ? 'winner_b' : 'winner_a';
            $tests[$i]['status']    = $winner;
            $tests[$i]['concluded'] = time();
            $tests[$i]['p_value']   = round($p_value, 4);
            $changed = true;
            $concluded_now[] = $tests[$i];
        }

        if ($changed) {
            self::save_tests($tests);
        }
        return $concluded_now;
    }

    /**
     * p-value آزمون z دو نسبت (تبدیل نسخه B در برابر A)
     * @param int $convA @param int $impA @param int $convB @param int $impB
     * @return float|null
     */
    private static function two_proportion_p_value($convA, $impA, $convB, $impB) {
        $impA = max(1, (int) $impA);
        $impB = max(1, (int) $impB);
        $pA   = $convA / $impA;
        $pB   = $convB / $impB;
        $p    = ($convA + $convB) / ($impA + $impB);
        $se   = sqrt($p * (1 - $p) * (1 / $impA + 1 / $impB));
        if ($se <= 0) {
            return null;
        }
        $z = abs($pB - $pA) / $se;
        return 2 * (1 - self::norm_cdf($z));
    }

    /**
     * تابع توزیع تجمعی نرمال استاندارد — تقریب erf (بدون افزونه PHP-Stats)
     * @param float $x
     * @return float
     */
    private static function norm_cdf($x) {
        $t = 1 / (1 + 0.3275911 * abs($x));
        $poly = ((((1.061405429 * $t - 1.453152027) * $t) + 1.421413741) * $t - 0.284496736) * $t + 0.254829592;
        $erf  = 1 - $poly * $t * exp(-$x * $x);
        return 0.5 * (1 + ($x >= 0 ? $erf : -$erf));
    }

    /* ───────────────────────── چرخه حیات تست (فراخوانی از ادمین) ───────────────────────── */

    /**
     * ساخت تست جدید با اعتبارسنجی کامل (خروجی: [success, message])
     * @param string $widget_slug @param string $title_b @param string $title_a @param string $color_b @param int $split
     * @return array
     */
    public static function create_test($widget_slug, $title_b, $title_a, $color_b, $split) {
        $widget_slug = sanitize_key((string) $widget_slug);
        $title_a     = sanitize_text_field((string) $title_a);
        $title_b     = sanitize_text_field((string) $title_b);
        $color_b     = strtoupper(trim((string) $color_b));

        if (!array_key_exists($widget_slug, self::testable_widgets())) {
            return array(false, 'ویجت انتخابی برای تست معتبر نیست.');
        }
        if (mb_strlen($title_a) > 120 || mb_strlen($title_b) > 120) {
            return array(false, 'طول عنوان‌ها حداکثر ۱۲۰ کاراکتر است.');
        }
        $color_valid = ('' !== $color_b) && preg_match('/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $color_b);
        if ('' === $title_b && !$color_valid) {
            return array(false, 'نسخه B باید دست‌کم یک تغییر داشته باشد: عنوان جدید یا رنگ جدید.');
        }
        if (self::running_test_for($widget_slug)) {
            return array(false, 'این ویجت هم‌اکنون یک تست فعال دارد؛ ابتدا آن را متوقف یا منتشر کنید.');
        }

        $tests = self::get_tests();
        if (count($tests) >= self::MAX_TESTS) {
            // قدیمی‌ترین تست‌های خاتمه‌یافته خودکار حذف می‌شوند تا سقف حفظ شود
            usort($tests, function($a, $b) {
                $ca = isset($a['concluded']) ? (int) $a['concluded'] : (int) $a['created'];
                $cb = isset($b['concluded']) ? (int) $b['concluded'] : (int) $b['created'];
                return $cb - $ca; // جدیدترین اول
            });
            $tests = array_slice($tests, 0, self::MAX_TESTS - 1);
            $tests = array_values(array_filter($tests, function($t) {
                return 'running' === $t['status'];
            }));
        }

        $tests[] = array(
            'id'       => 'ab_' . time() . '_' . wp_rand(100, 999),
            'widget'   => $widget_slug,
            'title_a'  => $title_a,
            'title_b'  => $title_b,
            'color_b'  => $color_valid ? strtolower($color_b) : '',
            'split'    => max(5, min(50, (int) $split)),
            'status'   => 'running',
            'created'  => time(),
            'concluded'=> 0,
        );
        self::save_tests($tests);
        return array(true, 'تست A/B با موفقیت آغاز شد؛ از این لحظه ترافیک بین نسخه A و B تقسیم می‌شود.');
    }

    /**
     * توقف/انتشار/بازنشانی تست
     * keep: 'publish_b' = نسخه B قفل شود | 'keep_a' = بازگشت به ظاهر فعلی (A) | 'reset' = بدون قفل
     * برای تست‌های قفل‌شده (winner) فقط 'reset' معنا دارد: آزاد کردن قفل
     * @param string $test_id @param string $keep
     * @return array
     */
    public static function stop_test($test_id, $keep) {
        $tests = self::get_tests();
        foreach ($tests as $i => $test) {
            if ($test['id'] !== (string) $test_id) {
                continue;
            }
            $is_running = ('running' === $test['status']);
            $is_locked  = in_array($test['status'], array('winner_a', 'winner_b'), true);
            if (!$is_running && !$is_locked) {
                continue;
            }

            if ($is_running && 'publish_b' === $keep) {
                $tests[$i]['status']    = 'winner_b';
                $tests[$i]['concluded'] = time();
                $tests[$i]['p_value']   = '';
                $msg = 'نسخه B به‌صورت دائمی منتشر شد و برای همه بازدیدکنندگان قفل شد.';
            } elseif ($is_running && 'keep_a' === $keep) {
                $tests[$i]['status']    = 'winner_a';
                $tests[$i]['concluded'] = time();
                $tests[$i]['p_value']   = '';
                $msg = 'تست متوقف و نسخه کنترل (A) برای همه بازدیدکنندگان قفل شد.';
            } else {
                // running + reset یا آزادسازی قفل برنده
                $tests[$i]['status']    = 'stopped';
                $tests[$i]['concluded'] = time();
                $msg = $is_locked
                    ? 'قفل برنده آزاد شد؛ ظاهر ویجت به حالت عادی تنظیمات بازگشت.'
                    : 'تست متوقف شد؛ ظاهر ویجت به حالت عادی بازگشت (بدون قفل).';
            }
            self::save_tests($tests);
            return array(true, $msg);
        }
        return array(false, 'تست فعال مورد نظر یافت نشد.');
    }

    /**
     * حذف کامل تست از تاریخچه
     * @param string $test_id
     * @return array
     */
    public static function delete_test($test_id) {
        $tests = self::get_tests();
        $kept  = array();
        $found = false;
        foreach ($tests as $test) {
            if ($test['id'] === (string) $test_id) {
                $found = true;
                continue;
            }
            $kept[] = $test;
        }
        if (!$found) {
            return array(false, 'تست مورد نظر یافت نشد.');
        }
        self::save_tests($kept);
        return array(true, 'تست از تاریخچه حذف شد.');
    }

    /**
     * ثبت هوک‌های همیشگی
     */
    public static function init() {
        add_filter('fws_style_variables', array(__CLASS__, 'filter_style_variables'), 20);
        // بررسی روزانه معناداری هم‌زمان با کرون پاکسازی ردیابی
        add_action('fws_daily_tracking_cleanup_event', array(__CLASS__, 'check_conclusions'));
    }
}
