<?php
/**
 * Class FWS_Ajax_Handler
 * پردازشگر امن و فوق‌سریع AJAX (حفاظت صددرصدی در برابر IDOR، اعتبارسنجی نانس، محافظت از انبار و ثبت تخفیف‌های هوشمند)
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class FWS_Ajax_Handler {

        private static $instance = null;

        public static function get_instance() {
                if ( null === self::$instance ) {
                        self::$instance = new self();
                }
                return self::$instance;
        }

        public function __construct() {
                add_action( 'wp_ajax_fws_add_bundle', array( $this, 'add_bundle_to_cart' ) );
                add_action( 'wp_ajax_nopriv_fws_add_bundle', array( $this, 'add_bundle_to_cart' ) );

                add_action( 'wp_ajax_fws_add_single', array( $this, 'add_single_to_cart' ) );
                add_action( 'wp_ajax_nopriv_fws_add_single', array( $this, 'add_single_to_cart' ) );

                add_action( 'wp_ajax_fws_thankyou_upsell', array( $this, 'process_thankyou_upsell' ) );
                add_action( 'wp_ajax_nopriv_fws_thankyou_upsell', array( $this, 'process_thankyou_upsell' ) );

                // اعمال کد تخفیف مودال خروج — تنها کد پیکربندی‌شده در پنل ادمین اعمال می‌شود
                add_action( 'wp_ajax_fws_apply_exit_coupon', array( $this, 'apply_exit_coupon' ) );
                add_action( 'wp_ajax_nopriv_fws_apply_exit_coupon', array( $this, 'apply_exit_coupon' ) );

                // BUG-10 fix (v2.8.1): nonce refresh for pages served from a full-page cache.
                add_action( 'wp_ajax_fws_refresh_nonce', array( $this, 'refresh_nonce' ) );
                add_action( 'wp_ajax_nopriv_fws_refresh_nonce', array( $this, 'refresh_nonce' ) );

                // نسخه ۲.۱۰: بیکن سبک ثبت نمایش واقعی مودال خروج از سمت مرورگر
                add_action( 'wp_ajax_fws_track_event', array( $this, 'track_event' ) );
                add_action( 'wp_ajax_nopriv_fws_track_event', array( $this, 'track_event' ) );

                add_action( 'wp_ajax_fws_recalculate_rules', array( $this, 'recalculate_rules' ) );
                add_action( 'wp_ajax_fws_optimize_database', array( $this, 'optimize_database' ) );
        }

        /**
         * شناسایی IP واقعی کاربر — نسخه ۲.۷: مقاوم در برابر جعل هدر
         *
         * نکته امنیتی: به هدرهای پروکسی (X-Forwarded-For و...) فقط زمانی اعتماد می‌شود که
         * درخواست مستقیماً از یک پروکسی معتبر (لیست `fws_trusted_proxies`) رسیده باشد؛
         * در غیر این صورت REMOTE_ADDR ملاک است چون هدرها قابل جعل‌اند و Rate-Limit را بی‌اثر می‌کردند.
         * فروشگاه‌های پشت کلودفلر/CDN می‌توانند با فیلتر `fws_trusted_proxies` بازه‌های CIDR را ثبت کنند.
         * @return string
         */
        private function get_client_ip() {
                $remote = ! empty( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
                if ( '' === $remote ) {
                        return '0.0.0.0';
                }

                $trusted = apply_filters( 'fws_trusted_proxies', array() );
                if ( ! empty( $trusted ) && $this->ip_matches_ranges( $remote, (array) $trusted ) && class_exists( 'WC_Geolocation' ) ) {
                        $real = \WC_Geolocation::get_ip_address();
                        if ( ! empty( $real ) ) {
                                return sanitize_text_field( $real );
                        }
                }
                return $remote;
        }

        /**
         * تطبیق IP با لیست IP/CIDR (پروکسی‌های معتبر)
         */
        private function ip_matches_ranges( $ip, $ranges ) {
                foreach ( $ranges as $range ) {
                        $range = trim( (string) $range );
                        if ( '' === $range ) {
                                continue;
                        }
                        if ( false !== strpos( $range, '/' ) ) {
                                if ( $this->ip_in_cidr( $ip, $range ) ) {
                                        return true;
                                }
                        } elseif ( $ip === $range ) {
                                return true;
                        }
                }
                return false;
        }

        /**
         * بررسی عضویت IP در یک بازه CIDR (پشتیبانی IPv4 و IPv6)
         */
        private function ip_in_cidr( $ip, $cidr ) {
                list($subnet, $bits) = array_pad( explode( '/', $cidr, 2 ), 2, null );
                $ip_bin              = @inet_pton( $ip );
                $subnet_bin          = @inet_pton( $subnet );
                if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
                        return false;
                }
                $max  = strlen( $ip_bin ) * 8;
                $bits = ( null === $bits ) ? $max : (int) $bits;
                if ( $bits < 0 || $bits > $max ) {
                        return false;
                }

                $bytes = (int) floor( $bits / 8 );
                $rem   = $bits % 8;
                if ( $bytes > 0 && substr( $ip_bin, 0, $bytes ) !== substr( $subnet_bin, 0, $bytes ) ) {
                        return false;
                }
                if ( $rem > 0 ) {
                        $mask = ( 0xFF << ( 8 - $rem ) ) & 0xFF;
                        if ( ( ord( $ip_bin[ $bytes ] ) & $mask ) !== ( ord( $subnet_bin[ $bytes ] ) & $mask ) ) {
                                return false;
                        }
                }
                return true;
        }

        /**
         * بررسی سقف نرخ مجاز درخواست‌ها (Rate Limiting) جهت حفاظت در برابر ربات‌ها، حملات DoS و Cart Stuffing
         */
        private function check_rate_limit( $action = 'cart_action', $limit = 30, $window = 60 ) {
                $ip  = $this->get_client_ip();
                $key = 'fws_rate_' . md5( $action . '_' . $ip );

                // BUG-13 fix (v2.8.1) + completion (v2.9.0): the old get_transient()/set_transient()
                // pair was a read-then-write race, so N parallel requests all saw the same counter
                // and all passed.
                //
                //  - Object cache present: atomic wp_cache_add() + wp_cache_incr(). If the key
                //    expires between add() and incr(), Redis previously created an orphan key
                //    WITHOUT a TTL that lived forever; we now retry add() to restore the TTL.
                //  - No object cache (most shared hosts): a single atomic INSERT ... ON DUPLICATE
                //    KEY UPDATE against wp_options (UNIQUE index on option_name) — the counter can
                //    never go backwards and parallel requests are correctly limited. The bucket
                //    value embeds its own expiry (count:unix_ts) and stale buckets are garbage-
                //    collected opportunistically (~2% of calls).
                $bucket_key = $key . '_' . (int) floor( time() / max( 1, $window ) );
                if ( wp_using_ext_object_cache() ) {
                        $added = wp_cache_add( $bucket_key, 1, 'fws_rate', $window );
                        if ( $added ) {
                                $attempts = 1;
                        } else {
                                $incr = wp_cache_incr( $bucket_key, 1, 'fws_rate' );
                                if ( false === $incr ) {
                                        // Key expired between add() and incr() — restore it with a TTL.
                                        $added    = wp_cache_add( $bucket_key, 1, 'fws_rate', $window );
                                        $attempts = $added ? 1 : (int) wp_cache_incr( $bucket_key, 1, 'fws_rate' );
                                } else {
                                        $attempts = (int) $incr;
                                }
                        }
                } else {
                        global $wpdb;
                        $bucket_value = '1:' . ( time() + max( 1, $window ) );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- atomic rate limiting primitive
                        $wpdb->query(
                                $wpdb->prepare(
                                        "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')
                                        ON DUPLICATE KEY UPDATE option_value = CONCAT( CAST( SUBSTRING_INDEX( option_value, ':', 1 ) AS UNSIGNED ) + 1, ':', SUBSTRING_INDEX( option_value, ':', -1 ) )",
                                        $bucket_key,
                                        $bucket_value
                                )
                        );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
                        $stored = $wpdb->get_var(
                                $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $bucket_key )
                        );
                        $attempts = 1;
                        if ( null !== $stored ) {
                                $parts    = explode( ':', (string) $stored );
                                $attempts = (int) $parts[0];
                        }
                        // Opportunistic GC: remove expired buckets so wp_options stays lean.
                        // NOTE (باگ ۱۰ نسخهٔ ۲.۹): الگوی LIKE هرگز نباید به‌صورت literal داخل prepare
                        // نوشته شود — «%_» در PHP 8 داخل vsprintf خطای Unknown format specifier
                        // (ValueError) می‌دهد؛ الگو باید آرگومانِ %s باشد.
                        if ( 0 === mt_rand( 0, 49 ) ) {
                                // phpcs:ignore WordPress.DB.DirectDatabaseQuery
                                $wpdb->query(
                                        $wpdb->prepare(
                                                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST( SUBSTRING_INDEX( option_value, ':', -1 ) AS UNSIGNED ) < %d",
                                                $wpdb->esc_like( 'fws_rate_' ) . '%',
                                                time()
                                        )
                                );
                        }
                }
                if ( $attempts > $limit ) {
                        wp_send_json_error( array( 'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کرده و سپس تلاش نمایید.' ) );
                }
        }

        /**
         * اعمال کد تخفیف مودال خروج به سبد خرید
         * امنیت: تنها کد تخفیفی که ادمین در پنل تنظیمات ثبت کرده اعمال می‌شود؛
         * ورودی کاربر هرگز به‌عنوان کد تخفیف مورد اعتماد قرار نمی‌گیرد.
         */
        public function apply_exit_coupon() {
                check_ajax_referer( 'fws_prediction_nonce', 'nonce' );
                $this->check_rate_limit( 'apply_coupon', 5, 60 );

                $configured_coupon = trim( (string) FWS_Settings::get( 'exit_intent_coupon', '' ) );
                if ( '' === $configured_coupon ) {
                        wp_send_json_error( array( 'message' => 'در حال حاضر کد تخفیف ویژه‌ای تعریف نشده است.' ) );
                }

                if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
                        wp_send_json_error( array( 'message' => 'سبد خرید در دسترس نیست. لطفاً صفحه را تازه‌سازی کنید.' ) );
                }

                // Ensure guest session exists so the coupon can be persisted on the cart
                if ( WC()->session && ! WC()->session->has_session() ) {
                        WC()->session->set_customer_session_cookie( true );
                }

                $applied = WC()->cart->apply_coupon( $configured_coupon );

                if ( ! $applied ) {
                        $notices    = wc_get_notices( 'error' );
                        $notice_msg = ! empty( $notices ) ? wp_strip_all_tags( reset( $notices )['notice'] ) : 'امکان اعمال این کد تخفیف وجود ندارد.';
                        wc_clear_notices();
                        wp_send_json_error( array( 'message' => $notice_msg ) );
                }

                wc_clear_notices(); // جلوگیری از نمایش دوباره پیام موفقیت در بارگذاری بعدی صفحه

                // نسخه ۲.۱۰: ثبت تعامل سطح بالای مودال خروج در قیف تبدیل
                if ( class_exists( 'FWS_Tracker' ) ) {
                        FWS_Tracker::log_coupon_apply();
                }

                wp_send_json_success(
                        array(
                                'message'      => 'کد تخفیف با موفقیت روی سبد خرید شما اعمال شد.',
                                'checkout_url' => wc_get_checkout_url(),
                        )
                );
        }

        /**
         * افزودن دسته‌ای اقلام پکیج و تنظیم سشن تخفیف
         *
         * امنیت نسخه ۲.۷: امضای HMAC سمت سرور — فقط شناسه‌هایی که در رندر باکس پکیج
         * (صفحه محصول) امضا شده‌اند مجاز به دریافت تخفیف پکیج هستند؛ در نتیجه ارسال
         * دستی product_ids دلخواه (Cart Stuffing) عملاً غیرممکن می‌شود.
         * تخفیف پکیج فقط با حداقل ۲ کالای واقعی از پکیج اعمال می‌شود.
         */
        public function add_bundle_to_cart() {
                check_ajax_referer( 'fws_prediction_nonce', 'nonce' );
                $this->check_rate_limit( 'add_bundle', 25, 60 );

                if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
                        wp_send_json_error( array( 'message' => 'سبد خرید در دسترس نیست. لطفاً صفحه را تازه‌سازی کنید.' ) );
                }

                $main_id   = isset( $_POST['main_id'] ) ? absint( $_POST['main_id'] ) : 0;
                $official  = isset( $_POST['bundle_ids'] ) ? array_filter( array_map( 'absint', preg_split( '/[,\\s]+/', sanitize_text_field( wp_unslash( $_POST['bundle_ids'] ) ) ) ) ) : array();
                $signature = isset( $_POST['bundle_sig'] ) ? sanitize_text_field( wp_unslash( $_POST['bundle_sig'] ) ) : '';
                $raw_ids   = isset( $_POST['product_ids'] ) ? (array) $_POST['product_ids'] : array();
                $submitted = array_filter( array_unique( array_map( 'absint', $raw_ids ) ) );

                // BUG-07 fix (v2.9.0): defense-in-depth for the variable/grouped/external source bug —
                // the box is no longer rendered for such products, but a hand-crafted POST could still
                // send their id as main_id; add_to_cart() would fail for them and only the extras
                // (with the discount) would land in the cart. Reject honestly instead.
                $main_product = wc_get_product( $main_id );
                if ( $main_product && $main_product->is_type( (array) apply_filters( 'fws_non_addable_product_types', array( 'variable', 'grouped', 'external' ) ) ) ) {
                        wp_send_json_error(
                                array(
                                        'message' => 'پکیج هوشمند برای محصولات متغیر/گروهی/پیوندی فعال نیست؛ ابتدا گزینه یا محصول مشخص را انتخاب کنید.',
                                )
                        );
                }

                // اعتبارسنجی امضای پکیج: امضا فقط برای جفت «محصول مبدأ + لیست رسمی پیشنهادها» معتبر است
                $expected_sig = hash_hmac( 'sha256', $main_id . '|' . implode( ',', $official ), wp_salt( 'auth' ) );
                if ( $main_id <= 0 || empty( $official ) || ! hash_equals( $expected_sig, $signature ) ) {
                        wp_send_json_error( array( 'message' => 'امضای پکیج نامعتبر است؛ لطفاً صفحه محصول را تازه‌سازی کرده و دوباره تلاش کنید.' ) );
                }

                // محصول اصلی همیشه بخشی از پکیج است
                if ( ! in_array( $main_id, $submitted, true ) ) {
                        $submitted[] = $main_id;
                }

                // فقط شناسه‌های داخل امضا پذیرفته می‌شوند؛ بقیه بی‌صدا حذف می‌شوند
                $allowed   = array_merge( array( $main_id ), $official );
                $valid_ids = array_values( array_intersect( $submitted, $allowed ) );
                if ( empty( $valid_ids ) ) {
                        wp_send_json_error( array( 'message' => 'هیچ محصول معتبری از پکیج انتخاب نشده است.' ) );
                }
                if ( count( $valid_ids ) > 10 ) {
                        $valid_ids = array_slice( $valid_ids, 0, 10 );
                }

                // Ensure customer session is created and persisted for guest users
                if ( WC()->session && ! WC()->session->has_session() ) {
                        WC()->session->set_customer_session_cookie( true );
                }

                // BUG-04 fix (v2.8.1): the discount must depend on what actually landed in the cart,
                // not on how many ids were submitted (an add_to_cart() call can fail, e.g. for a
                // variable parent or a stock race). Only successfully added ids are tracked.
                $added_ids = array();
                // نسخه ۲.۱۰: برچسب منبع و نسخه A/B روی هر آیتم سبد ثبت می‌شود تا خرید نهایی به ویجت مبدا منتسب شود
                $fws_src_meta = array(
                        'fws_source'  => 'product',
                        'fws_variant' => class_exists( 'FWS_AB_Testing' ) ? FWS_AB_Testing::effective_variant( 'product' ) : '',
                );
                foreach ( $valid_ids as $pid ) {
                        $product = wc_get_product( $pid );
                        if ( $product && $product->is_purchasable() && $product->is_in_stock() ) {
                                $cart_item_key = WC()->cart->add_to_cart( $pid, 1, 0, array(), $fws_src_meta );
                                if ( $cart_item_key ) {
                                        $added_ids[] = (int) $pid;
                                }
                        }
                }
                $added = count( $added_ids );

                // Bundle discount only makes sense when at least 2 bundle items are really in the cart.
                $apply_discount = ( $added >= 2 );

                if ( $added === 0 ) {
                        $notices    = wc_get_notices( 'error' );
                        $notice_msg = ! empty( $notices ) ? wp_strip_all_tags( reset( $notices )['notice'] ) : 'محصولات انتخابی در انبار موجود یا قابل سفارش نیستند.';
                        wc_clear_notices();
                        wp_send_json_error( array( 'message' => $notice_msg ) );
                }

                // سشن تخفیف فقط پس از افزودن موفق و فقط برای لیست اعتبارسنجی‌شده ثبت می‌شود (رفع آلودگی سشن در مسیر خطا)
                if ( $apply_discount && WC()->session ) {
                        $existing = (array) WC()->session->get( 'fws_bundle_items', array() );
                        $merged   = array_unique( array_merge( $existing, $added_ids ) );
                        WC()->session->set( 'fws_bundle_items', $merged );

                        // نسخه ۲.۹.۱ — مجموعهٔ کامل «امضاشده»: مبنای بازگردانی (Undo) قلم‌های حذف‌شده
                        // در fast-woo-sale.php. این مجموعه هرگز با حذف قلم کوچک نمی‌شود؛ فقط شناسه‌های
                        // HMAC-تأییدشده را نگه می‌دارد (سقف ۵۰ — کهن‌ترین‌ها حذف می‌شوند) و چون قاعدهٔ
                        // «حداقل ۲ کالا» در before_calculate_totals سر جایش است، بازگرداندن شناسه‌ها
                        // هیچ مسیر تخفیف نابهجایی باز نمی‌کند.
                        $signed     = (array) WC()->session->get( 'fws_bundle_signed', array() );
                        $signed_all = array_slice( array_values( array_unique( array_map( 'intval', array_merge( $signed, $added_ids ) ) ) ), -50 );
                        WC()->session->set( 'fws_bundle_signed', $signed_all );
                }

                // نسخه ۲.۱۰: ثبت رخداد «افزودن به سبد» در قیف تبدیل ویجت باکس محصول
                if ( class_exists( 'FWS_Tracker' ) ) {
                        FWS_Tracker::log_add_to_cart( 'product', $added_ids );
                }

                ob_start();
                woocommerce_mini_cart();
                $mini_cart = ob_get_clean();

                $message = $apply_discount
                        ? sprintf( '%d محصول با تخفیف پکیج به سبد خرید افزوده شد.', $added )
                        : sprintf( '%d محصول به سبد افزوده شد؛ تخفیف پکیج فقط با انتخاب حداقل ۲ کالا اعمال می‌شود.', $added );

                wp_send_json_success(
                        array(
                                'message'    => $message,
                                'cart_count' => WC()->cart->get_cart_contents_count(),
                                'cart_url'   => wc_get_cart_url(),
                                'cart_hash'  => WC()->cart->get_cart_hash(),
                                'fragments'  => apply_filters(
                                        'woocommerce_add_to_cart_fragments',
                                        array(
                                                'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
                                        )
                                ),
                        )
                );
        }

        /**
         * افزودن سریع کالای پرکننده یا پیشنهادی
         */
        public function add_single_to_cart() {
                check_ajax_referer( 'fws_prediction_nonce', 'nonce' );
                $this->check_rate_limit( 'add_single', 30, 60 );

                $pid        = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
                // نسخه ۲.۱۰: زمینه ویجت مبدا از دیتای دکمه (با اعتبارسنجی وایت‌لیست سمت سرور)
                $src_widget = isset( $_POST['fws_widget'] ) ? sanitize_key( wp_unslash( $_POST['fws_widget'] ) ) : '';
                if ( $pid > 0 ) {
                        $product = wc_get_product( $pid );
                        if ( $product && $product->is_purchasable() && $product->is_in_stock() ) {
                                if ( WC()->session && ! WC()->session->has_session() ) {
                                        WC()->session->set_customer_session_cookie( true );
                                }
                                $fws_src_meta = array(
                                        'fws_source'  => ( class_exists( 'FWS_Tracker' ) && '' !== FWS_Tracker::resolve_slug( $src_widget ) ) ? FWS_Tracker::resolve_slug( $src_widget ) : 'unknown',
                                        'fws_variant' => class_exists( 'FWS_AB_Testing' ) ? FWS_AB_Testing::effective_variant( $src_widget ) : '',
                                );
                                $cart_item_key = WC()->cart->add_to_cart( $pid, 1, 0, array(), $fws_src_meta );
                                if ( $cart_item_key ) {
                                        // نسخه ۲.۱۰: ثبت رخداد «افزودن به سبد» در قیف تبدیل ویجت مبدا
                                        if ( class_exists( 'FWS_Tracker' ) ) {
                                                FWS_Tracker::log_add_to_cart( $src_widget, array( $pid ) );
                                        }
                                        ob_start();
                                        woocommerce_mini_cart();
                                        $mini_cart = ob_get_clean();

                                        wp_send_json_success(
                                                array(
                                                        'message'    => 'محصول با موفقیت به سبد افزوده شد.',
                                                        'cart_count' => WC()->cart->get_cart_contents_count(),
                                                        'cart_url'   => wc_get_cart_url(),
                                                        'cart_hash'  => WC()->cart->get_cart_hash(),
                                                        'fragments'  => apply_filters(
                                                                'woocommerce_add_to_cart_fragments',
                                                                array(
                                                                        'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
                                                                )
                                                        ),
                                                )
                                        );
                                } else {
                                        $notices    = wc_get_notices( 'error' );
                                        $notice_msg = ! empty( $notices ) ? wp_strip_all_tags( reset( $notices )['notice'] ) : 'امکان افزودن این کالا به سبد خرید وجود ندارد.';
                                        wc_clear_notices();
                                        wp_send_json_error( array( 'message' => $notice_msg ) );
                                }
                        } else {
                                wp_send_json_error( array( 'message' => 'این کالا در حال حاضر موجود یا قابل سفارش نیست.' ) );
                        }
                }
                wp_send_json_error( array( 'message' => 'شناسه محصول نامعتبر است.' ) );
        }

        /**
         * Return a fresh front-end nonce.
         *
         * BUG-10 fix (v2.8.1): the nonce printed into product/cart HTML is frozen by page caches
         * (WP Rocket, LiteSpeed, CDN) and expires after 12-24h, after which every button failed with
         * "invalid signature". The JS retries a failed request once with a nonce from this endpoint.
         * The endpoint is intentionally nonce-free (a nonce is not a secret, it only binds a session)
         * and is rate limited like every other public action.
         */
        public function refresh_nonce() {
                $this->check_rate_limit( 'refresh_nonce', 20, 60 );
                nocache_headers();
                wp_send_json_success( array( 'nonce' => wp_create_nonce( 'fws_prediction_nonce' ) ) );
        }

        /**
         * افزودن ۱ کلیکی آپسل به سفارش جاری (محافظت کامل از IDOR و جلوگیری از ثبت تکراری)
         */
        public function process_thankyou_upsell() {
                check_ajax_referer( 'fws_prediction_nonce', 'nonce' );
                $this->check_rate_limit( 'thankyou_upsell', 10, 60 );

                $order_id   = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
                $order_key  = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';
                $product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

                $order   = wc_get_order( $order_id );
                $product = wc_get_product( $product_id );

                if ( ! $order || ! $product ) {
                        wp_send_json_error( array( 'message' => 'اطلاعات سفارش یا کالا نامعتبر است.' ) );
                }

                // Strict Anti-IDOR Authorization Check: Verify either authenticated customer ID or cryptographic Order Key
                $current_user_id = get_current_user_id();
                $is_owner        = ( $current_user_id > 0 && $order->get_user_id() === $current_user_id );
                $valid_key       = ( ! empty( $order_key ) && hash_equals( $order->get_order_key(), $order_key ) );

                if ( ! $is_owner && ! $valid_key && ! current_user_can( 'manage_woocommerce' ) ) {
                        wp_send_json_error( array( 'message' => 'خطای امنیتی: دسترسی غیرمجاز به این سفارش.' ) );
                }

                // Only allow modification for orders in modifiable status
                if ( ! in_array( $order->get_status(), array( 'pending', 'on-hold', 'processing' ), true ) ) {
                        wp_send_json_error( array( 'message' => 'امکان تغییر سفارش با وضعیت فعلی آن وجود ندارد.' ) );
                }

                // BUG-03 fix (v2.8.1): never raise the total of an order that was already paid through an
                // online gateway - no new payment would be collected and the order would become "half paid".
                // Allowed: orders that still need payment (customer is redirected to the pay page below)
                // and orders placed with offline gateways (cash on delivery, bank transfer, cheque).
                $offline_gateways = apply_filters( 'fws_upsell_offline_gateways', array( 'cod', 'bacs', 'cheque' ) );
                $is_offline       = in_array( $order->get_payment_method(), (array) $offline_gateways, true );
                if ( $order->is_paid() && ! $is_offline ) {
                        wp_send_json_error(
                                array(
                                        'message' => 'پرداخت این سفارش انجام شده و امکان افزودن کالا به آن وجود ندارد. می‌توانید این کالا را جداگانه سفارش دهید.',
                                )
                        );
                }

                // Idempotency: Prevent duplicate addition via order meta and existing order items
                $meta_flag = '_fws_upsell_added_' . $product_id;
                if ( $order->get_meta( $meta_flag ) ) {
                        wp_send_json_error( array( 'message' => 'این محصول قبلاً به سفارش شما افزوده شده است.' ) );
                }
                foreach ( $order->get_items() as $existing_item ) {
                        if ( $existing_item->get_product_id() === $product_id || $existing_item->get_variation_id() === $product_id ) {
                                wp_send_json_error( array( 'message' => 'این محصول قبلاً در این سفارش ثبت شده است.' ) );
                        }
                }

                // Stock & purchasable verification
                if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) {
                        wp_send_json_error( array( 'message' => 'متأسفانه موجودی این کالا در انبار به اتمام رسیده است.' ) );
                }

                // نسخه ۲.۷ — ضد دستکاری تخفیف: فقط کالایی که موتور پیش‌بینی واقعاً برای این سفارش
                // پیشنهاد داده است با تخفیف آپسل قابل افزودن است؛ ارسال product_id دلخواه رد می‌شود.
                $engine          = FWS_Prediction_Engine::get_instance();
                $expected_upsell = $engine->get_post_purchase_upsell( $order_id );
                if ( ! $expected_upsell || (int) $expected_upsell['product_id'] !== $product_id ) {
                        wp_send_json_error( array( 'message' => 'این کالا جزو پیشنهادهای اختصاصی سیستم برای سفارش شما نیست.' ) );
                }

                // Calculate discounted price
                // BUG-08 fix (v2.9.0): the discount basis must be the catalogue regular price (the
                // honest "was" price), not the current price which may already be on sale.
                // BUG-01 fix (v2.9.0): order line totals are always stored tax-EXCLUSIVE
                // (WC_Abstract_Order::add_product uses wc_get_price_excluding_tax). On stores with
                // "prices entered with tax" enabled (common in Iranian shops) get_price()/
                // get_regular_price() are tax-INCLUSIVE; passing them straight into subtotal/total
                // made calculate_totals() stack tax on top of an already-taxed amount and the
                // customer was overcharged versus the displayed box price. Normalize first.
                $discount_pct = max( 0, min( 90, floatval( FWS_Settings::get( 'upsell_discount', 20 ) ) ) );
                $basis_price  = (float) $product->get_regular_price();
                if ( $basis_price <= 0 ) {
                        $basis_price = (float) $product->get_price();
                }
                if ( function_exists( 'wc_get_price_excluding_tax' ) ) {
                        $basis_price = (float) wc_get_price_excluding_tax( $product, array( 'price' => $basis_price ) );
                }
                $discounted_price = round( $basis_price * ( ( 100 - $discount_pct ) / 100 ), wc_get_price_decimals() );

                $item_id = $order->add_product(
                        $product,
                        1,
                        array(
                                'subtotal' => $discounted_price,
                                'total'    => $discounted_price,
                        )
                );

                if ( ! $item_id ) {
                        wp_send_json_error( array( 'message' => 'خطا در الحاق محصول به سفارش. لطفاً مجدداً تلاش کنید.' ) );
                }

                // نسخه ۲.۱۰: برچسب منبع روی آیتم سفارش برای انتساب درآمد به ویجت «صفحه تشکر»
                if ( function_exists( 'wc_add_order_item_meta' ) ) {
                        wc_add_order_item_meta( $item_id, 'fws_source', 'thankyou' );
                        $fws_upsell_variant = class_exists( 'FWS_AB_Testing' ) ? FWS_AB_Testing::effective_variant( 'thankyou' ) : '';
                        if ( in_array( $fws_upsell_variant, array( 'A', 'B' ), true ) ) {
                                wc_add_order_item_meta( $item_id, 'fws_variant', $fws_upsell_variant );
                        }
                }

                // Mark as added and record customer note
                $order->update_meta_data( $meta_flag, current_time( 'mysql' ) );
                $order->calculate_totals();
                $order->add_order_note(
                        sprintf(
                                'محصول مکمل «%s» با %s٪ تخفیف اختصاصی (%s) از طریق سیستم پیشنهاد هوشمند به سفارش افزوده شد.',
                                $product->get_name(),
                                $discount_pct,
                                wc_price( $discounted_price )
                        )
                );
                $order->save();

                // BUG-02 fix (v2.8.1): WooCommerce reduces stock once, on the payment/status transition.
                // An item appended later never triggers that hook. If stock has already been reduced for
                // this order, reduce it for the new line too (wc_reduce_stock_levels() is idempotent per
                // item via the _reduced_stock item meta). For unpaid orders WC will reduce it on payment.
                if ( $order->get_data_store()->get_stock_reduced( $order_id ) ) {
                        wc_reduce_stock_levels( $order );
                }

                // نسخه ۲.۱۰: سفارش صفحه تشکر معمولاً همین حالا در وضعیت processing است و
                // دیگر گذار وضعیت ندارد؛ انتساب idempotent همین‌جا هم اجرا می‌شود (یک بار برای همیشه)
                if ( class_exists( 'FWS_Tracker' ) ) {
                        FWS_Tracker::attribute_order( $order->get_id() );
                }

                $response = array(
                        'message'   => 'کالای مکمل با موفقیت و با تخفیف ویژه به سفارش شما اضافه شد!',
                        'new_total' => $order->get_formatted_order_total(),
                );
                if ( $order->needs_payment() ) {
                        $response['pay_url'] = $order->get_checkout_payment_url();
                        $response['message'] = 'کالا به سفارش افزوده شد؛ در حال انتقال به صفحه پرداخت مبلغ جدید…';
                }
                wp_send_json_success( $response );
        }

        /**
         * بازسازی الگوها با احراز هویت ادمین
         */
        public function recalculate_rules() {
                check_ajax_referer( 'fws_admin_nonce', 'nonce' );

                if ( ! current_user_can( 'manage_woocommerce' ) ) {
                        wp_send_json_error( array( 'message' => 'عدم دسترسی مجاز.' ) );
                }

                if ( get_transient( 'fws_mining_lock' ) ) {
                        wp_send_json_error( array( 'message' => 'عملیات تحلیل داده‌ها هم‌اکنون در پس‌زمینه در حال اجرا است. لطفاً شکیبا باشید.' ) );
                }

                $count = FWS_Database_Miner::run_market_basket_analysis();
                wp_send_json_success( array( 'rules_count' => $count ) );
        }

        /**
         * بهینه‌سازی دیتابیس با احراز هویت ادمین
         */
        public function optimize_database() {
                check_ajax_referer( 'fws_admin_nonce', 'nonce' );

                if ( ! current_user_can( 'manage_woocommerce' ) ) {
                        wp_send_json_error( array( 'message' => 'عدم دسترسی مجاز.' ) );
                }

                FWS_Performance_Optimizer::optimize_database_tables();
                wp_send_json_success( array( 'message' => 'جداول با موفقیت Defragment، ایندکس‌ها بهینه‌سازی و ترنزینت‌های منقضی پاکسازی شدند.' ) );
        }

        /**
         * نسخه ۲.۱۰ — بیکن سبک ثبت رخدادهای فرانت (فعلاً: نمایش واقعی مودال خروج)
         * امنیت: نانس صفحه + Rate-Limit + وایت‌لیست سخت نوع رخداد؛ هیچ ورودی آزادی‌ای پذیرفته نمی‌شود.
         */
        public function track_event() {
                check_ajax_referer( 'fws_prediction_nonce', 'nonce' );
                $this->check_rate_limit( 'track_event', 60, 60 );

                $type = isset( $_POST['track_type'] ) ? sanitize_key( wp_unslash( $_POST['track_type'] ) ) : '';
                if ( 'exit_shown' === $type && class_exists( 'FWS_Tracker' ) ) {
                        FWS_Tracker::log_exit_modal_shown();
                }
                // پاسخ کم‌حجم و بی‌صدا — بیکن نباید هیچ اثر جانبی UI داشته باشد
                wp_send_json_success( array( 'ok' => true ) );
        }
}
