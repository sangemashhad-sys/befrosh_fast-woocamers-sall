<?php
/**
 * Plugin Name: Fast Woo Predictive Purchase | سیستم هوشمند پیش‌بینی و پیشنهاد خرید ووکامرس
 * Plugin URI:  https://github.com/fast-woo-sale/predictive-purchase
 * Description: موتور تحلیل پیشرفته دیتابیس سفارشات ووکامرس، استخراج سبدهای پرتکرار (Market Basket Analysis)، پیش‌بینی خرید بعدی و ارائه پیشنهادات هوشمند کالا.
 * Version:     2.10.0
 * Author:      تیم توسعه هوش تجاری ووکامرس
 * Author URI:  https://example.com
 * Text Domain: fast-woo-sale
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * WC requires at least: 8.0
 * WC tested up to: 9.3
 *
 * License:     GPL v2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly.
}

// Safe check for WooCommerce dependency (compatible with alphabetical plugin loading & multisite)
function fws_check_woocommerce_active() {
        $active_plugins = (array) get_option( 'active_plugins', array() );
        if ( is_multisite() ) {
                $active_plugins = array_merge( $active_plugins, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
        }
        return in_array( 'woocommerce/woocommerce.php', $active_plugins, true ) || class_exists( 'WooCommerce' );
}

add_action(
        'admin_notices',
        function () {
                if ( ! fws_check_woocommerce_active() ) {
                        if ( ! current_user_can( 'activate_plugins' ) ) {
                                return;
                        }
                        echo '<div class="notice notice-error is-dismissible"><p><strong>سیستم هوشمند پیش‌بینی خرید (Fast Woo Predictive):</strong> برای اجرای این سیستم، نصب و فعال‌سازی افزونه WooCommerce الزامی است.</p></div>';
                }
        }
);

// Define Constants
// FWS_BUNDLE_DISCOUNT و FWS_MIN_CONFIDENCE برای سازگاری قبلی حفظ شده‌اند؛
// مقادیر واقعی از پنل تنظیمات (FWS_Settings) خوانده می‌شوند.
define( 'FWS_VERSION', '2.10.0' );
define( 'FWS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'FWS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'FWS_MIN_CONFIDENCE', 60 );
define( 'FWS_BUNDLE_DISCOUNT', 12 );

// Declare HPOS & Blocks Compatibility (High-Performance Order Storage & Cart/Checkout Blocks)
add_action(
        'before_woocommerce_init',
        function () {
                if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
                        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
                        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
                }
        }
);

// Apply bundle discount directly into WooCommerce cart calculations
// نسخه ۲.۷ — رفع باگ تخفیف ترکیبی (Compounding Discount):
// مبنای محاسبه باید همیشه «قیمت پایه ثبت‌شده هنگام افزودن به سبد» باشد؛ استفاده از
// min(regular, current) باعث می‌شد با هر بازمحاسبه سبد، تخفیف روی قیمتِ تخفیف‌خوردهٔ قبل
// دوباره اعمال شود (۱۰۰ → ۸۸ → ۷۷.۴۴ → … → نزدیک صفر).
add_action(
        'woocommerce_add_cart_item_data',
        function ( $cart_item_data, $product_id, $variation_id ) {
                if ( ! function_exists( 'wc_get_product' ) ) {
                        return $cart_item_data;
                }
                $product = wc_get_product( $variation_id > 0 ? $variation_id : $product_id );
                if ( ! $product ) {
                        return $cart_item_data;
                }
                $regular = (float) $product->get_regular_price();
                $current = (float) $product->get_price();
                $base    = ( $regular > 0 && $current > 0 ) ? min( $regular, $current ) : max( $regular, $current );
                if ( $base > 0 ) {
                        $cart_item_data['fws_base_price'] = $base;
                }
                return $cart_item_data;
        },
        10,
        3
);

add_action(
        'woocommerce_before_calculate_totals',
        function ( $cart ) {
                if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
                        return;
                }
                if ( ! function_exists( 'WC' ) || ! WC()->session || ! is_a( $cart, 'WC_Cart' ) ) {
                        return;
                }

                $bundle_items = (array) WC()->session->get( 'fws_bundle_items', array() );
                if ( empty( $bundle_items ) ) {
                        return;
                }

                // نسخه ۲.۹ — قاعدهٔ «حداقل ۲ کالا» در لحظهٔ بازمحاسبه هم اعمال می‌شود:
                // قبلاً فقط هنگام افزودن چک می‌شد؛ اگر کاربر همهٔ اقلام پکیج را جز یکی از سبد
                // حذف می‌کرد (و هوک حذف، سشن را به یک آیتم می‌چید)، همان تک‌کالا همچنان
                // تخفیف پکیج می‌گرفت — یعنی تخفیفِ بدونِ پکیج.
                // نسخه ۲.۹.۲ — باگ شمارشِ واریاسیون‌ها: قبلاً همیشه «پدر» (product_id) در لیست
                // برخورد ثبت می‌شد؛ اگر دو واریاسیونِ متفاوت از یک محصولِ والدِ واحد عضو پکیج
                // بودند (سناریوی ممکن از مسیر فیلتر توسعه‌دهنده fws_product_recommendations)،
                // هر دو خط سبد فقط «یک» برخورد حساب می‌شد و قاعدهٔ حداقل‌۲ تخفیف را بی‌صدا
                // قطره‌چکانی می‌بُرد. اکنون شناسهٔ واقعاً برخوردی (والد یا واریاسیون) ثبت می‌شود.
                $cart_bundle_hits = array();
                foreach ( $cart->get_cart() as $cart_item ) {
                        $pid = absint( $cart_item['product_id'] );
                        $vid = ! empty( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0;
                        if ( in_array( $pid, $bundle_items, true ) ) {
                                $cart_bundle_hits[] = $pid;
                        } elseif ( $vid > 0 && in_array( $vid, $bundle_items, true ) ) {
                                $cart_bundle_hits[] = $vid;
                        }
                }
                if ( count( array_unique( $cart_bundle_hits ) ) < 2 ) {
                        return;
                }

                $discount_percentage = (int) FWS_Settings::get( 'bundle_discount', defined( 'FWS_BUNDLE_DISCOUNT' ) ? FWS_BUNDLE_DISCOUNT : 12 );
                $factor              = ( 100 - max( 0, min( 90, $discount_percentage ) ) ) / 100;

                foreach ( $cart->get_cart() as $cart_item ) {
                        $pid            = absint( $cart_item['product_id'] );
                        $vid            = ! empty( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0;
                        $is_bundle_item = in_array( $pid, $bundle_items, true ) || ( $vid > 0 && in_array( $vid, $bundle_items, true ) );

                        if ( $is_bundle_item && isset( $cart_item['data'] ) && is_object( $cart_item['data'] ) ) {
                                // مبنای idempotent: قیمت پایهٔ ثبت‌شده هنگام افزودن؛ برای اقلام قدیمی سشن (قبل از ارتقا)
                                // قیمت اصلی (regular) ملاک است تا هیچ‌گاه تخفیف به‌صورت تراکمی تکرار نشود.
                                $base_price = ! empty( $cart_item['fws_base_price'] )
                                ? (float) $cart_item['fws_base_price']
                                : (float) $cart_item['data']->get_regular_price();

                                if ( $base_price > 0 ) {
                                        $discounted = round( $base_price * $factor, wc_get_price_decimals() );
                                        $cart_item['data']->set_price( $discounted );
                                }
                        }
                }
        },
        20,
        1
);

// Keep bundle session items synchronized if user removes items or empties cart
add_action(
        'woocommerce_cart_item_removed',
        function ( $cart_item_key, $cart ) {
                if ( WC()->session ) {
                        $bundle_items = (array) WC()->session->get( 'fws_bundle_items', array() );
                        if ( ! empty( $bundle_items ) ) {
                                $current_cart_pids = array();
                                foreach ( $cart->get_cart() as $item ) {
                                        $current_cart_pids[] = absint( $item['product_id'] );
                                        if ( ! empty( $item['variation_id'] ) ) {
                                                $current_cart_pids[] = absint( $item['variation_id'] );
                                        }
                                }
                                $updated_bundle = array_values( array_intersect( $bundle_items, $current_cart_pids ) );
                                WC()->session->set( 'fws_bundle_items', $updated_bundle );
                        }
                }
        },
        10,
        2
);

// نسخه ۲.۹.۱ — باگ ۴: بازگردانی آیتم حذف‌شده (Undo) در سبد خرید.
// هوک حذف، شناسهٔ قلم را از لیست تخفیف سشن بیرون می‌کشد تا «تک‌کالای یتیم» هرگز تخفیف پکیج نگیرد؛
// اما اگر کاربر بلافاصله Undo بزند، همان قلم به سبد برمی‌گردد و چون از سشن حذف شده بود، تخفیف
// پکیجش بی‌صدا از بین می‌رفت با آنکه هر دو کالای پکیج دوباره در سبد بودند. راه‌حل: مجموعهٔ کامل
// «امضاشده» (fws_bundle_signed — فقط شناسه‌های HMAC-تأییدشده، سقف ۵۰) جداگانه نگهداری می‌شود و
// در لحظهٔ بازگردانی، شناسه‌های معتبر دوباره به لیست تخفیف برمی‌گردند. قاعدهٔ «حداقل ۲ کالا» در
// woocommerce_before_calculate_totals همچنان ضامن صحت است (بدون دو قلمِ واقعی، هیچ تخفیفی اعمال نمی‌شود).
add_action(
        'woocommerce_cart_item_restored',
        function ( $cart_item_key, $cart ) {
                if ( ! function_exists( 'WC' ) || ! WC()->session ) {
                        return;
                }
                $item = $cart->get_cart_item( $cart_item_key );
                if ( empty( $item ) ) {
                        return;
                }
                $signed = (array) WC()->session->get( 'fws_bundle_signed', array() );
                if ( empty( $signed ) ) {
                        return;
                }
                $ids_to_check = array( absint( $item['product_id'] ) );
                if ( ! empty( $item['variation_id'] ) ) {
                        $ids_to_check[] = absint( $item['variation_id'] );
                }
                $items   = (array) WC()->session->get( 'fws_bundle_items', array() );
                $updated = $items;
                foreach ( $ids_to_check as $cid ) {
                        if ( $cid > 0 && in_array( $cid, $signed, true ) && ! in_array( $cid, $updated, true ) ) {
                                $updated[] = $cid;
                        }
                }
                if ( count( $updated ) !== count( $items ) ) {
                        WC()->session->set( 'fws_bundle_items', array_values( $updated ) );
                }
        },
        10,
        2
);

add_action(
        'woocommerce_cart_emptied',
        function () {
                if ( WC()->session ) {
                        WC()->session->__unset( 'fws_bundle_items' );
                        WC()->session->__unset( 'fws_bundle_signed' );
                }
        }
);

// Load Core Modules (Settings must load first — all modules depend on it)
require_once FWS_PLUGIN_DIR . 'includes/class-fws-settings.php';
// Keep the FWS_Settings in-request memo coherent when the option is written by any code path.
add_action( 'update_option_' . FWS_Settings::OPTION_KEY, array( 'FWS_Settings', 'flush_memo' ) );
add_action( 'add_option_' . FWS_Settings::OPTION_KEY, array( 'FWS_Settings', 'flush_memo' ) );
add_action( 'delete_option_' . FWS_Settings::OPTION_KEY, array( 'FWS_Settings', 'flush_memo' ) );
require_once FWS_PLUGIN_DIR . 'includes/class-fws-style-manager.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-tracker.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-database-miner.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-prediction-engine.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-ab-testing.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-display-hooks.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-ajax-handler.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-insights.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-admin-analytics.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-admin-page.php';
require_once FWS_PLUGIN_DIR . 'includes/class-fws-performance-optimizer.php';

// نسخهٔ ۲.۹.۳ — بی‌اعتبارسازی کش پیشنهادات پس از تغییر دادهٔ کاتالوگ (رفع باگ کشِ کهنهٔ ۲۴ ساعته):
// ردیف‌های کش‌شدهٔ موتور، نام/قیمت/تصویر محصول و حکم «قابل‌پیشنهاد بودن» را در لحظهٔ ساخت
// منجمد می‌کنند. تغییر قیمت، شروع/پایان حراج، صفر شدن موجودی یا مخفی‌شدن محصول تا ۲۴ ساعت
// در ویجت‌ها اعمال نمی‌شد: قیمت نمایشی باکس پکیج با مبلغ واقعیِ سبد نمی‌خواند و دکمهٔ
// افزودن روی کالای ناموجود مرده می‌ماند. دو هوک زیر (هر دو رسمی در ووکامرس ۳.۰+ و
// پوشش‌دهندهٔ واریاسیون‌ها) هر تغییر مرتبط را به پاکسازی کامل کش موتور گره می‌زنند؛
// پاکسازی ارزان است (یک update_option + flush گروه) و فقط با تغییر پراپرتی‌های نمایشی
// رخ می‌دهد، نه با هر به‌روزرسانی محصول.
add_action( 'woocommerce_product_object_updated_props', array( 'FWS_Prediction_Engine', 'on_product_data_changed' ), 10, 2 );
add_action( 'woocommerce_product_set_stock_status', array( 'FWS_Prediction_Engine', 'purge_engine_cache' ), 10, 0 );
add_action( 'woocommerce_variation_set_stock_status', array( 'FWS_Prediction_Engine', 'purge_engine_cache' ), 10, 0 );

// Plugin Activation: Create High-Performance Cache Index Table
register_activation_hook( __FILE__, array( 'FWS_Database_Miner', 'create_tables_and_schedule' ) );
register_activation_hook( __FILE__, array( 'FWS_Tracker', 'maybe_upgrade' ) );
register_deactivation_hook( __FILE__, array( 'FWS_Database_Miner', 'clear_scheduled_events' ) );

// Initialize Engine
add_action(
        'plugins_loaded',
        function () {
                if ( ! class_exists( 'WooCommerce' ) ) {
                        return;
                }
                FWS_Database_Miner::init();
                FWS_Prediction_Engine::get_instance();
                FWS_Style_Manager::get_instance();
                FWS_Display_Hooks::get_instance();
                FWS_Ajax_Handler::get_instance();
                FWS_Performance_Optimizer::init();
                // نسخهٔ ۲.۱۰: موتور ردیابی و A/B تست — در همه مسیرها (خرید در فرانت هم ردیابی می‌شود)
                FWS_Tracker::init();
                FWS_AB_Testing::init();
                if ( is_admin() ) {
                        FWS_Admin_Page::get_instance();
                }
        }
);
