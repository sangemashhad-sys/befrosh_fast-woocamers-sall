=== Fast Woo Predictive Purchase ===
Contributors: sangemashhad
Tags: woocommerce, recommendations, market basket, cross-sell, upsell
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
WC requires at least: 8.0
Stable tag: 2.10.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Market-basket analysis of your own WooCommerce orders, turned into product bundles, cart complements, one-click thank-you upsells and next-purchase predictions. Everything runs on your server.

== Description ==

* Mines paid orders (WooCommerce Analytics lookup tables) into a product affinity table with confidence and lift.
* Storefront widgets: product-page bundle, cart complements, thank-you one-click upsell, free-shipping progress bar, account next-purchase prediction, search banner.
* Manual rules and blacklist override the algorithm.
* Full appearance control: disable plugin CSS, presets, CSS variables, custom CSS. No font injection.
* No external requests, no telemetry.

== Changelog ==

= 2.10.1 =
* Fix (dbDelta): the affinity-table CREATE used `IF NOT EXISTS` and `INDEX` keywords — dbDelta cannot diff that format, so future schema changes (new columns/indexes) could silently fail to apply on upgrades. Rewritten in canonical dbDelta form (`CREATE TABLE`, `KEY`, `PRIMARY KEY` spacing).
* Fix (db growth): every widget render inserted one `fws_events` row; high-traffic stores with 180-day retention could reach millions of rows. Impressions are now deduplicated per (session, widget) within a 6-hour window via a dedicated `session_widget_time` index — refreshes and multi-page browsing no longer multiply rows, while clicks/coupons/purchases stay row-per-event. Meaning of "impression" becomes "unique visitor per window" (arguably more accurate).
* Change (default): `tracking_retention_days` default 180 → 60 days (recommended for shared hosting); installs still on the untouched 180 migrate once to 60 — deliberate custom values are preserved. Admin field hint updated.
* Change (default): thank-you one-click upsell now ships disabled for new installs. The upsell appends an item to a REGISTERED order, which can clash with invoicing, accounting and the Iranian Moadian (سامانه مؤدیان) e-invoicing workflow — shop managers must opt in knowingly; a warning is shown next to both the widget toggle and the upsell-discount field. Existing installs keep their current choice.
* New (insight): when mining produced zero rules, the dashboard now explains why — either the WooCommerce Analytics lookup tables are still empty (with the exact rebuild path) or the min-support threshold is not met yet at current order volume (with concrete suggestions). Adds transparency for low-volume stores.
* New (repo hygiene): Plugin URI / Author URI now point to the real GitHub repository (previously a placeholder repo and `example.com`), a full `LICENSE` file (GPL-2.0-or-later) ships with the plugin, and a lightweight GitHub Actions workflow (`php -l` on every file + informational PHPStan) runs on push.
* New (i18n groundwork): `load_plugin_textdomain('fast-woo-sale')` now runs on init; strings remain hardcoded Persian for now (target market), so future translation files work without any loader change.
* Meta: `WC tested up to` bumped 9.3 → 10.3.

= 2.10.0 =
* New: Revenue attribution engine — every widget's funnel (impressions, add-to-carts, attributed orders/revenue) is tracked in a dedicated `fws_events` table and shown in a new dashboard card with 7/30/90-day switches ("how much has this plugin actually sold?"). Organic purchases are never attributed, so the number stays honest.
* New: Live A/B testing for widget titles and accent color. Visitors get a stable variant via the WooCommerce session; when the two-proportion z-test reaches significance (p < 0.05, min 100 impressions per variant) the winner is announced automatically and locked for everyone. Manual stop/publish/lock-release controls included.
* New: Smart insights cards built from real store data only — enabled-but-never-seen widgets, high-impression/zero-conversion widgets, blacklisted products that are actually top complements, low-stock top complements, fresh A/B winners, exit modal shown without coupon applies.
* Privacy & control: tracking master switch, IP anonymization (default on), exclude shop managers, automatic daily cleanup with a configurable retention window (30–365 days). Per-widget tracking follows the existing per-widget display toggles — a disabled widget records nothing. `fws_tracking_enabled` filter for developers.
* New option keys: `tracking_enable`, `tracking_anonymize_ip`, `tracking_exclude_admins`, `tracking_retention_days`. New table `{prefix}fws_events` (auto-created and self-healing); dropped automatically on uninstall.

= 2.9.3 =
* Fix (freshness): recommendation caches held a 24h snapshot of product name/price/image and of the "is recommendable" verdict — price changes, sale start/end, stock-status flips or hiding a product kept widgets outdated for up to 24 hours (the bundle box total could disagree with what the cart actually charged, and one-click buttons stayed dead on sold-out products). Catalog changes through the official WooCommerce hooks now purge the engine cache immediately (products AND variations).
* Fix (cache coherence): after a cache purge, the same request still wrote new cache rows under the OLD cache version — the in-request version/memoization is now reset as part of every purge.
* Fix (settings sync): the engine cache was only flushed on option UPDATE; the very first save (add_option) and full option deletion (reset) now flush it too, so new thresholds take effect immediately on fresh installs.
* Fix (widgets): fws_* shortcodes placed in sidebar widgets (Text / Block / Custom HTML) never loaded the front-end script, leaving every quick-add button in the widget silently dead; active widget options are now scanned as well.
* Fix (mining): reinstalling the plugin while an orphaned cron event from a previous install survived could schedule a duplicate initial mining run; the immediate event is only scheduled when nothing is already pending within the next 5 minutes.
* Cleanup: cart-recommendation cache keys are now order-insensitive (cart [A,B] and [B,A] share one cache row).
* Cleanup: the bundle button restores its server-rendered label exactly (previously the ⚡ emoji was re-added after a click even when emojis were disabled in settings).

= 2.9.2 =
* Fix (roles): shop managers could open the plugin settings page but the "Save" form silently failed with "You need a higher level of permission" — wp-admin/options.php requires manage_options by default; the save capability for this settings group is now aligned with the page (manage_woocommerce).
* Fix (appearance): custom CSS child selectors like ".menu > li" were silently corrupted because the ">" character was stripped along with HTML tags; only "<" is removed now (tags are already stripped and inline CSS cannot escape its <style> container without "<").
* Fix (cart): the min-2-bundle-items rule counted only parent product ids, so two variations of the same parent (possible via the fws_product_recommendations developer filter) were counted as one and the bundle discount was silently dropped; the matched id (parent or variation) is now recorded.
* Fix (search): when matched search products had no affinity rules yet, the indexed aggregate query re-ran on every search page view (twice — banner + injection); empty results are now cached with a short 10-minute TTL.
* Fix (maintenance): the admin "optimize" button's orphan cleanup did not filter by post_type, so rules whose product id had been recycled by a non-product post survived until the weekly cron; now aligned with the miner's weekly cleanup.

= 2.9.1 =
* Fix (mining): the "incomplete mining" admin notice was erased by the very same run that set it (the memory-guard break fell through to the cleanup code) — it now survives until a clean run finishes.
* Fix (mining): re-mining no longer keeps stale affinity rules computed under an older lookback/min_support/min_confidence configuration; after a complete run, only rows refreshed by this run remain (recommendations now truly match the configured analysis window).
* Fix (cart): removing a bundle item and then using Undo no longer silently drops that item's bundle discount — a full signed-id set is kept per session and re-synced on restore; the min-2-items rule still guarantees no discount without two real bundle items.
* Fix (honesty): the free-shipping progress bar now subtracts coupon discounts with the matching tax portion when prices are displayed including tax (previously the remaining amount was overstated on tax-enabled stores).
* Cleanup: corrected a stale comment in the search-recommendation cache (empty match-sets are intentionally persisted with a short TTL).

= 2.9.0 =
* Fix (money): tax-inclusive stores no longer overcharge the thank-you upsell line — item totals are now normalized with wc_get_price_excluding_tax before being written to the order (order line totals are always tax-exclusive).
* Fix (honesty): the struck-through "was" price of the upsell box is now the catalogue regular price, not the current (already discounted) price.
* Fix (data quality): mining now joins the orders table and counts only paid/successful orders (completed/processing) — abandoned/failed/refunded checkouts no longer pollute confidence, lift and frequencies.
* Fix (consistency): the admin "minimum confidence" setting is now honoured in all six recommendation paths (cart, thank-you upsell, user prediction, search banner previously ignored it).
* Fix (UX): the thank-you upsell box is no longer rendered for orders already paid through an online gateway (the button was always rejected server-side).
* Fix (security): rate limiting on shared hosts is now a single atomic INSERT..ON DUPLICATE KEY UPDATE counter (parallel requests can no longer bypass it); the Redis orphan-key edge is handled too.
* Fix: variable/grouped/external products no longer get the bundle box as the SOURCE product either (render + AJAX guard) — no more "2 items added" without the main product.
* Fix: search-term title matching is cached for 10 minutes — the heavy LIKE scan no longer runs on every search page view.
* Fix: style_text no longer blanks a whole label when the source string is invalid UTF-8.
* Fix (PHP 8 fatal): the rate-limit garbage collection query passed a literal % pattern inside prepare() — now passed as a proper argument.
* Fix (money): removing all bundle items except one no longer keeps the 12% bundle discount on the lone item (min-2 rule is enforced at cart recalculation time too).
* Fix: tier-2 -> tier-1 cache promotion no longer extends short-TTL entries to 24h (capped at 15 minutes).
* Improvement: honest free-shipping bar — uses displayed subtotal minus coupon discounts; filler row title no longer claims "to reach free shipping" when no filler bridges the gap; bridging fillers are sorted first.
* Improvement: incomplete mining (memory guard) now leaves an admin notice; cleanups (batch size, dead if(true), unused free_shipping_limit JS param, multisite uninstall note).

= 2.8.1 =
* Fix: settings form was never wrapped in a <form>; "Save settings" now works (Settings API).
* Fix: thank-you upsell now reduces stock when the order stock was already reduced, and refuses to raise the total of an order already paid online (unpaid / offline-gateway orders are redirected to pay).
* Fix: bundle discount applies only to items actually added to the cart.
* Fix: variable/grouped/external products are no longer offered in one-click widgets.
* Fix: search-term cache is keyed on matched product ids (no more transient flooding).
* Fix: mining lock is released on fatal/timeout.
* Fix: search injection only on explicit product searches.
* Fix: recs_limit / min_confidence honoured in cart and free-shipping widgets.
* Fix: stale nonce on cached pages is refreshed automatically.
* Fix: user prediction cache purged on new order; uninstall clears weekly cron; atomic rate limiter; admin JS TypeError; 32-bit crc32; settings memoized per request.

= 2.8.0 =
* Appearance panel: style toggle, presets, palette, typography, custom CSS, live preview.
* Fixed unstyled cart grid and bundle item classes.

See CHANGELOG-*.md files for full history.
