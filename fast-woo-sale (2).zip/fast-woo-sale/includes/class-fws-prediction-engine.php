<?php
/**
 * Class FWS_Prediction_Engine
 * موتور استخراج پیشنهادات هوشمند، لایه کش دو سطحی (Redis / Transients API) جهت سرعت صفر تأخیر
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWS_Prediction_Engine {

    private static $instance = null;
    private static $memoized_cache = array();
    private static $cache_ver = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function get_cache_version() {
        if (null === self::$cache_ver) {
            self::$cache_ver = (int) get_option('fws_cache_version', 1);
        }
        return self::$cache_ver;
    }

    /**
     * سیستم کش ۳ لایه فوق‌سریع:
     * لایه ۰: حافظه موقت PHP (Static Memoization) با پاسخ‌دهی در ۰.۰۰۱ میلی‌ثانیه
     * لایه ۱: Redis / Memcached Persistent Object Cache
     * لایه ۲: جدول Transients پایگاه‌داده با ایندکس B-Tree
     */
    private function get_cache($key) {
        // Tier 0: In-Memory Static Cache (0.001ms, Zero DB hits, Zero network socket calls)
        if (isset(self::$memoized_cache[$key])) {
            return self::$memoized_cache[$key];
        }

        $ver = $this->get_cache_version();
        $full_key = "fws_{$key}_v{$ver}";

        // Tier 1: Check Object Cache / Redis
        $cached = wp_cache_get($full_key, FWS_Database_Miner::CACHE_GROUP);
        if (false !== $cached) {
            self::$memoized_cache[$key] = $cached;
            return $cached;
        }

        // Tier 2: Fallback to Transients API for hosts without Redis
        $transient = get_transient($full_key);
        if (false !== $transient) {
            wp_cache_set($full_key, $transient, FWS_Database_Miner::CACHE_GROUP, 24 * HOUR_IN_SECONDS);
            self::$memoized_cache[$key] = $transient;
            return $transient;
        }

        return false;
    }

    private function set_cache($key, $data) {
        self::$memoized_cache[$key] = $data;
        $ver = $this->get_cache_version();
        $full_key = "fws_{$key}_v{$ver}";
        $ttl = 24 * HOUR_IN_SECONDS;

        wp_cache_set($full_key, $data, FWS_Database_Miner::CACHE_GROUP, $ttl);
        set_transient($full_key, $data, $ttl);
    }

    /**
     * دریافت محصولات مکمل پیشنهادی با استفاده از لایه کش بهینه و بررسی سلامت انبار
     */
    public function get_recommendations_for_product($product_id, $limit = 3) {
        $product_id = absint($product_id);
        if ($product_id <= 0) return array();

        $cache_key = "rec_{$product_id}_{$limit}";
        $cached = $this->get_cache($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        global $wpdb;
        $affinity_table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;

        // Candidate lookahead buffer: دریافت کاندیداهای بیشتر جهت تضمین پر بودن پیشنهادها حتی در صورت اتمام موجودی انبار برخی اقلام
        $candidate_limit = max(10, $limit * 3);
        $results = $wpdb->get_results($wpdb->prepare("
            SELECT 
                recommended_product_id,
                confidence_score,
                co_occurrence,
                lift_score
            FROM {$affinity_table}
            WHERE source_product_id = %d
              AND confidence_score >= %f
            ORDER BY confidence_score DESC, co_occurrence DESC
            LIMIT %d
        ", $product_id, floatval(60), $candidate_limit));

        $recommendations = array();
        if (!empty($results)) {
            // Prime Core WordPress Post & PostMeta caches in a SINGLE query (رفع قطعی مشکل N+1 کوئری در ووکامرس)
            $rec_pids = array();
            foreach ($results as $item) {
                $rec_pids[] = absint($item->recommended_product_id);
            }
            if (!empty($rec_pids) && function_exists('_prime_post_caches')) {
                _prime_post_caches($rec_pids, true, true);
            }

            foreach ($results as $item) {
                if (count($recommendations) >= $limit) {
                    break;
                }
                $product = wc_get_product($item->recommended_product_id);
                if ($product && $product->is_visible() && $product->is_in_stock() && $product->is_purchasable()) {
                    $recommendations[] = array(
                        'product_id'   => $product->get_id(),
                        'name'         => $product->get_name(),
                        'price'        => (float) $product->get_price(),
                        'regular_price'=> (float) $product->get_regular_price(),
                        'image'        => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                        'confidence'   => (float) $item->confidence_score,
                        'co_orders'    => (int) $item->co_occurrence,
                        'lift'         => (float) $item->lift_score,
                        'is_fallback'  => false,
                    );
                }
            }
        }

        // Smart Category Fallback (Cold-Start Protection for new/low-volume products)
        if (count($recommendations) < $limit) {
            $needed = $limit - count($recommendations);
            $exclude_ids = array($product_id);
            foreach ($recommendations as $rec) {
                $exclude_ids[] = $rec['product_id'];
            }
            $fallbacks = $this->get_category_fallbacks($product_id, $needed, $exclude_ids);
            foreach ($fallbacks as $fb) {
                $recommendations[] = $fb;
            }
        }

        $recommendations = apply_filters('fws_product_recommendations', $recommendations, $product_id, $limit);
        $this->set_cache($cache_key, $recommendations);
        return $recommendations;
    }

    /**
     * فال‌بک هوشمند دسته‌بندی برای کالاهای بدون سابقه سبد خرید (حل مسئله Cold-Start)
     */
    public function get_category_fallbacks($product_id, $limit = 2, $exclude_ids = array()) {
        $terms = wc_get_product_term_ids($product_id, 'product_cat');
        if (empty($terms)) return array();

        $args = array(
            'post_type'              => 'product',
            'post_status'            => 'publish',
            'posts_per_page'         => max(4, $limit * 2),
            'post__not_in'           => $exclude_ids,
            'tax_query'              => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $terms,
                ),
            ),
            'meta_key'               => 'total_sales',
            'orderby'                => 'meta_value_num',
            'order'                  => 'DESC',
            'fields'                 => 'ids',
            'no_found_rows'          => true,
            'update_post_term_cache' => false,
            'update_post_meta_cache' => false,
        );

        $query = new WP_Query($args);
        $fallbacks = array();

        if ($query->have_posts()) {
            foreach ($query->posts as $fb_id) {
                if (count($fallbacks) >= $limit) break;
                $prod = wc_get_product($fb_id);
                if ($prod && $prod->is_visible() && $prod->is_in_stock() && $prod->is_purchasable()) {
                    $fallbacks[] = array(
                        'product_id'   => $prod->get_id(),
                        'name'         => $prod->get_name(),
                        'price'        => (float) $prod->get_price(),
                        'regular_price'=> (float) $prod->get_regular_price(),
                        'image'        => wp_get_attachment_image_url($prod->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                        'confidence'   => 70.0,
                        'co_orders'    => 0,
                        'lift'         => 1.5,
                        'is_fallback'  => true,
                    );
                }
            }
        }

        return apply_filters('fws_category_fallbacks', $fallbacks, $product_id, $limit);
    }

    /**
     * هوش مالی سبد خرید: پیدا کردن کالای پرکننده بهینه برای رسیدن به سقف ارسال رایگان
     */
    public function get_free_shipping_fillers($cart_total, $threshold) {
        if ($cart_total >= $threshold) {
            return array();
        }

        $gap = $threshold - $cart_total;
        $cart_items = WC()->cart ? WC()->cart->get_cart() : array();
        $cart_product_ids = array();
        foreach ($cart_items as $item) {
            $cart_product_ids[] = absint($item['product_id']);
        }

        $cart_product_ids = array_filter(array_unique(array_map('absint', $cart_product_ids)));
        if (empty($cart_product_ids)) return array();

        global $wpdb;
        $affinity_table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;
        $in_placeholders = implode(',', array_fill(0, count($cart_product_ids), '%d'));

        // Find accessories or complementary items whose price bridges the free-shipping gap
        $candidates = $wpdb->get_results($wpdb->prepare("
            SELECT recommended_product_id, MAX(confidence_score) as max_conf
            FROM {$affinity_table}
            WHERE source_product_id IN ({$in_placeholders})
              AND recommended_product_id NOT IN ({$in_placeholders})
            GROUP BY recommended_product_id
            ORDER BY max_conf DESC
            LIMIT 4
        ", array_merge($cart_product_ids, $cart_product_ids)));

        $fillers = array();
        if (!empty($candidates)) {
            foreach ($candidates as $cand) {
                $prod = wc_get_product($cand->recommended_product_id);
                if ($prod && $prod->is_in_stock() && $prod->is_purchasable()) {
                    $price = (float) $prod->get_price();
                    $fillers[] = array(
                        'product_id'   => $prod->get_id(),
                        'name'         => $prod->get_name(),
                        'price'        => $price,
                        'image'        => wp_get_attachment_image_url($prod->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                        'confidence'   => (float) $cand->max_conf,
                        'bridges_gap'  => ($price >= $gap),
                    );
                }
            }
        }

        return $fillers;
    }

    /**
     * پیش‌بینی محصول مکمل برتر پس از ثبت سفارش در صفحه تشکر (1-Click Post Purchase Upsell)
     */
    public function get_post_purchase_upsell($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return null;

        $purchased_ids = array();
        foreach ($order->get_items() as $item) {
            $purchased_ids[] = absint($item->get_product_id());
        }
        $purchased_ids = array_filter(array_unique(array_map('absint', $purchased_ids)));
        if (empty($purchased_ids)) return null;

        global $wpdb;
        $affinity_table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;
        $in_placeholders = implode(',', array_fill(0, count($purchased_ids), '%d'));

        $top_match = $wpdb->get_row($wpdb->prepare("
            SELECT recommended_product_id, MAX(confidence_score) as best_conf, MAX(lift_score) as best_lift
            FROM {$affinity_table}
            WHERE source_product_id IN ({$in_placeholders})
              AND recommended_product_id NOT IN ({$in_placeholders})
            GROUP BY recommended_product_id
            ORDER BY best_conf DESC, best_lift DESC
            LIMIT 1
        ", array_merge($purchased_ids, $purchased_ids)));

        if (!$top_match) return null;

        $product = wc_get_product($top_match->recommended_product_id);
        if (!$product || !$product->is_in_stock() || !$product->is_purchasable()) return null;

        $regular = (float) $product->get_price();
        $discount_pct = max(0, min(90, floatval(20)));
        $discounted = round($regular * ((100 - $discount_pct) / 100), wc_get_price_decimals());

        return array(
            'product_id'        => $product->get_id(),
            'name'              => $product->get_name(),
            'regular_price'     => $regular,
            'discounted_price'  => $discounted,
            'discount_percent'  => $discount_pct,
            'confidence'        => (float) $top_match->best_conf,
            'image'             => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
        );
    }

    /**
     * پیش‌بینی خرید بعدی کاربر لاگین‌شده بر اساس سابقه خریدهای قبلی (Personalized RFM)
     */
    public function get_user_next_purchase_prediction($user_id) {
        $user_id = absint($user_id);
        if ($user_id <= 0) return null;

        $cache_key = "user_rec_{$user_id}";
        $cached = $this->get_cache($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        $customer_orders = wc_get_orders(array(
            'customer' => $user_id,
            'limit'    => 10,
            'status'   => array('wc-completed', 'wc-processing'),
            'orderby'  => 'date',
            'order'    => 'DESC',
        ));

        if (empty($customer_orders)) return null;

        $purchased_product_ids = array();
        foreach ($customer_orders as $order) {
            foreach ($order->get_items() as $item) {
                $purchased_product_ids[] = absint($item->get_product_id());
            }
        }
        $purchased_product_ids = array_filter(array_unique(array_map('absint', $purchased_product_ids)));
        if (empty($purchased_product_ids)) return null;

        global $wpdb;
        $affinity_table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;
        $in_placeholders = implode(',', array_fill(0, count($purchased_product_ids), '%d'));

        $candidates = $wpdb->get_results($wpdb->prepare("
            SELECT recommended_product_id, AVG(confidence_score) as avg_conf, SUM(co_occurrence) as sum_orders
            FROM {$affinity_table}
            WHERE source_product_id IN ({$in_placeholders})
              AND recommended_product_id NOT IN ({$in_placeholders})
            GROUP BY recommended_product_id
            ORDER BY avg_conf DESC
            LIMIT 4
        ", array_merge($purchased_product_ids, $purchased_product_ids)));

        if (!empty($candidates)) {
            foreach ($candidates as $candidate) {
                $product = wc_get_product($candidate->recommended_product_id);
                if ($product && $product->is_in_stock() && $product->is_purchasable()) {
                    $prediction = array(
                        'product_id' => $product->get_id(),
                        'name'       => $product->get_name(),
                        'price'      => (float) $product->get_price(),
                        'image'      => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                        'confidence' => round($candidate->avg_conf, 1),
                    );
                    $this->set_cache($cache_key, $prediction);
                    return $prediction;
                }
            }
        }

        return null;
    }

    /**
     * استخراج فوق‌سریع کل پیشنهادات سبد خرید با یک کوئری تجمیعی ریاضی به جای کوئری‌های تکراری
     */
    public function get_cart_recommendations($cart_product_ids, $limit = 3) {
        $cart_product_ids = array_filter(array_unique(array_map('absint', (array) $cart_product_ids)));
        if (empty($cart_product_ids)) return array();

        $cache_key = 'cart_recs_' . md5(implode('_', $cart_product_ids)) . "_{$limit}";
        $cached = $this->get_cache($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        global $wpdb;
        $affinity_table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;
        $in_placeholders = implode(',', array_fill(0, count($cart_product_ids), '%d'));

        $candidate_limit = max(10, $limit * 3);
        $query_params = array_merge($cart_product_ids, $cart_product_ids, array($candidate_limit));
        $results = $wpdb->get_results($wpdb->prepare("
            SELECT 
                recommended_product_id, 
                MAX(confidence_score) as best_conf, 
                SUM(co_occurrence) as total_co
            FROM {$affinity_table}
            WHERE source_product_id IN ({$in_placeholders})
              AND recommended_product_id NOT IN ({$in_placeholders})
            GROUP BY recommended_product_id
            ORDER BY best_conf DESC, total_co DESC
            LIMIT %d
        ", $query_params));

        $recommendations = array();
        if (!empty($results)) {
            // Prime Core WordPress Post & PostMeta caches in a single query
            $rec_pids = array();
            foreach ($results as $row) {
                $rec_pids[] = absint($row->recommended_product_id);
            }
            if (!empty($rec_pids) && function_exists('_prime_post_caches')) {
                _prime_post_caches($rec_pids, true, true);
            }

            foreach ($results as $row) {
                if (count($recommendations) >= $limit) {
                    break;
                }
                $product = wc_get_product($row->recommended_product_id);
                if ($product && $product->is_visible() && $product->is_in_stock() && $product->is_purchasable()) {
                    $recommendations[] = array(
                        'product_id' => $product->get_id(),
                        'name'       => $product->get_name(),
                        'price'      => (float) $product->get_price(),
                        'image'      => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                        'confidence' => (float) $row->best_conf,
                    );
                }
            }
        }

        $this->set_cache($cache_key, $recommendations);
        return $recommendations;
    }

    /**
     * پیش‌بینی و استخراج کالاهای مکمل با بیشترین نرخ خرید همزمان برای عبارت جستجوشده کاربر
     * بهینه‌سازی‌شده برای عدم اسکن متن طولانی و پاسخ‌دهی زیر ۲ میلی‌ثانیه
     */
    public function get_search_co_occurrence_recommendations($search_query, $limit = 2) {
        $search_query = sanitize_text_field(trim($search_query));
        if (empty($search_query) || mb_strlen($search_query) < 2) {
            return array();
        }

        $cache_key = 'search_rec_' . md5($search_query) . "_{$limit}";
        $cached = $this->get_cache($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        global $wpdb;

        // 1. پیدا کردن آیدی محصولات تطابق‌یافته با کلمه کلیدی جستجو (فقط روی عنوان کالا جهت استفاده ۱۰۰٪ از ایندکس و عدم اسکن محتوا)
        $wildcard = '%' . $wpdb->esc_like($search_query) . '%';
        $matching_product_ids = $wpdb->get_col($wpdb->prepare("
            SELECT ID FROM {$wpdb->posts}
            WHERE post_type = 'product'
              AND post_status = 'publish'
              AND post_title LIKE %s
            ORDER BY ID DESC
            LIMIT 6
        ", $wildcard));

        if (empty($matching_product_ids)) {
            return array();
        }

        $affinity_table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;
        $in_placeholders = implode(',', array_fill(0, count($matching_product_ids), '%d'));

        // 2. کوئری استخراج مکمل‌ها با استفاده از ایندکس ترکیبی پوششی (Covering Index)
        $query_params = array_merge($matching_product_ids, $matching_product_ids, array($limit * 3));
        $results = $wpdb->get_results($wpdb->prepare("
            SELECT 
                recommended_product_id,
                source_product_id,
                MAX(confidence_score) as max_conf,
                SUM(co_occurrence) as total_co
            FROM {$affinity_table}
            WHERE source_product_id IN ({$in_placeholders})
              AND recommended_product_id NOT IN ({$in_placeholders})
            GROUP BY recommended_product_id
            ORDER BY total_co DESC, max_conf DESC
            LIMIT %d
        ", $query_params));

        $recommendations = array();
        if (!empty($results)) {
            $prime_ids = array();
            foreach ($results as $row) {
                $prime_ids[] = absint($row->recommended_product_id);
                $prime_ids[] = absint($row->source_product_id);
            }
            if (!empty($prime_ids) && function_exists('_prime_post_caches')) {
                _prime_post_caches(array_unique($prime_ids), true, true);
            }

            foreach ($results as $row) {
                if (count($recommendations) >= $limit) break;
                $product = wc_get_product($row->recommended_product_id);
                $source = wc_get_product($row->source_product_id);
                if ($product && $product->is_visible() && $product->is_in_stock() && $product->is_purchasable()) {
                    $recommendations[] = array(
                        'product_id'    => $product->get_id(),
                        'name'          => $product->get_name(),
                        'price'         => (float) $product->get_price(),
                        'regular_price' => (float) $product->get_regular_price() ?: (float) $product->get_price(),
                        'image'         => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                        'confidence'    => round((float) $row->max_conf, 1),
                        'co_occurrence' => (int) $row->total_co,
                        'source_name'   => $source ? $source->get_name() : $search_query,
                        'reason'        => sprintf('پرفروش‌ترین مکمل خریداری‌شده در کنار «%s»', $source ? $source->get_name() : $search_query),
                    );
                }
            }
        }

        $this->set_cache($cache_key, $recommendations);
        return $recommendations;
    }
}
