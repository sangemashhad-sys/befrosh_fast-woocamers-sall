<?php
/**
 * Class FWS_Display_Hooks
 * تزریق ویجت‌های فرانت‌اند ووکامرس برای نمایش پیشنهادات دیتابیس
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWS_Display_Hooks {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        // Enqueue Assets
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        // Single Product Page Recommendation Box
        add_action('woocommerce_after_single_product_summary', array($this, 'render_product_recommendations_box'), 25);

        // Cart Page Upsell Box
        add_action('woocommerce_after_cart_table', array($this, 'render_cart_recommendations_box'), 15);

        // Sales Booster 1: Post-Purchase 1-Click Upsell in Thank-You Page
        add_action('woocommerce_thankyou', array($this, 'render_thank_you_upsell_box'), 10);

        // Sales Booster 2: Dynamic Free Shipping Progress Bar with Smart Fillers
        add_action('woocommerce_before_cart_table', array($this, 'render_free_shipping_progress_bar'), 5);

        // Sales Booster 3: Exit-Intent Cart Abandonment Rescue Modal
        add_action('wp_footer', array($this, 'render_exit_intent_rescue_modal'));

        // Customer Account Next Purchase Prediction
        add_action('woocommerce_account_dashboard', array($this, 'render_my_account_prediction_widget'), 10);

        // Growth Tool 9: Predictive Search Booster (ارتقای نتایج جستجو با پرفروش‌ترین کالای مکمل)
        add_action('woocommerce_before_shop_loop', array($this, 'render_search_complementary_banner'), 12);
        add_filter('the_posts', array($this, 'inject_complementary_into_search_results'), 10, 2);

        // Shortcode support for Gutenberg, Elementor, and custom themes
        add_shortcode('fws_predicted_products', array($this, 'shortcode_handler'));
        add_shortcode('fws_bundle', array($this, 'render_bundle_shortcode'));
        add_shortcode('fws_free_shipping_bar', array($this, 'render_free_shipping_shortcode'));
        add_shortcode('fws_cart_recommendations', array($this, 'render_cart_recommendations_shortcode'));
    }

    public function enqueue_scripts() {
        if (is_admin()) return;

        // Conditional asset loading: only load scripts & styles where needed to protect PageSpeed & Core Web Vitals
        $should_load = is_product() || is_cart() || is_checkout() || is_account_page() || (is_search() && true);
        global $post;
        if (!$should_load && is_a($post, 'WP_Post') && (
            has_shortcode($post->post_content, 'fws_predicted_products') ||
            has_shortcode($post->post_content, 'fws_bundle') ||
            has_shortcode($post->post_content, 'fws_free_shipping_bar') ||
            has_shortcode($post->post_content, 'fws_cart_recommendations')
        )) {
            $should_load = true;
        }

        if (!$should_load) {
            return;
        }

        wp_enqueue_style('fws-recommendations', FWS_PLUGIN_URL . 'assets/css/fws-recommendations.css', array(), FWS_VERSION);
        wp_enqueue_script('fws-recommendations', FWS_PLUGIN_URL . 'assets/js/fws-recommendations.js', array('jquery'), FWS_VERSION, true);

        // Defer script loading for optimal TTFB and First Contentful Paint
        add_filter('script_loader_tag', function($tag, $handle) {
            if ('fws-recommendations' === $handle && false === strpos($tag, 'defer')) {
                return str_replace(' src', ' defer="defer" src', $tag);
            }
            return $tag;
        }, 10, 2);

        wp_localize_script('fws-recommendations', 'fws_params', array(
            'ajax_url'            => admin_url('admin-ajax.php'),
            'nonce'               => wp_create_nonce('fws_prediction_nonce'),
            'bundle_discount'     => 12,
            'free_shipping_limit' => 2000000,
            'currency_symbol'     => function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : 'تومان',
            'added_text'          => __('پکیج با موفقیت به سبد خرید اضافه شد', 'fast-woo-sale'),
        ));
    }

    /**
     * رندر باکس هوشمند محصولات خریداری‌شده با این کالا در صفحه محصول
     */
    public function render_product_recommendations_box($custom_product_id = 0) {
        $product_id = $custom_product_id > 0 ? absint($custom_product_id) : 0;
        if ($product_id <= 0) {
            global $product;
            $product_id = ($product && is_a($product, 'WC_Product')) ? $product->get_id() : 0;
        }

        $product = wc_get_product($product_id);
        if (!$product) return;

        $engine = FWS_Prediction_Engine::get_instance();
        $recommendations = $engine->get_recommendations_for_product($product->get_id(), 3);

        if (empty($recommendations)) return;

        $main_price = (float) $product->get_price();
        $total_bundle_original = $main_price;
        foreach ($recommendations as $rec) {
            $total_bundle_original += (float) $rec['price'];
        }
        $discount_factor = (100 - 12) / 100;
        $total_bundle_discounted = $total_bundle_original * $discount_factor;
        ?>
        <div class="fws-bundle-wrapper" dir="rtl">
            <div class="fws-bundle-header">
                <span class="fws-bundle-badge">تحلیل دیتابیس سفارشات</span>
                <h3 class="fws-bundle-title">پیشنهادهای هوشمند دیتابیس (خریداری‌شده با این کالا)</h3>
                <p class="fws-bundle-subtitle">بر اساس تحلیل سوابق خرید و رفتار مشتریان این فروشگاه</p>
            </div>

            <div class="fws-bundle-items">
                <!-- Main Product -->
                <div class="fws-bundle-item is-primary">
                    <input type="checkbox" checked disabled class="fws-check-item" data-price="<?php echo esc_attr($main_price); ?>" value="<?php echo esc_attr($product->get_id()); ?>">
                    <span class="fws-item-thumb">
                        <?php echo $product->get_image('thumbnail', array('loading' => 'lazy', 'decoding' => 'async')); ?>
                    </span>
                    <div class="fws-item-info">
                        <span class="fws-item-tag">محصول فعلی</span>
                        <strong class="fws-item-name"><?php echo esc_html($product->get_name()); ?></strong>
                        <span class="fws-item-price"><?php echo wc_price($main_price); ?></span>
                    </div>
                </div>

                <div class="fws-plus-sign">+</div>

                <!-- Recommended Co-Occurrence Products -->
                <?php foreach ($recommendations as $idx => $rec): ?>
                    <div class="fws-bundle-item is-recommended" data-product-id="<?php echo esc_attr($rec['product_id']); ?>">
                        <input type="checkbox" checked class="fws-check-item" data-price="<?php echo esc_attr($rec['price']); ?>" value="<?php echo esc_attr($rec['product_id']); ?>">
                        <span class="fws-item-thumb">
                            <img src="<?php echo esc_url($rec['image']); ?>" alt="<?php echo esc_attr($rec['name']); ?>" loading="lazy" decoding="async" width="56" height="56">
                        </span>
                        <div class="fws-item-info">
                            <span class="fws-confidence-tag">
                                <?php echo esc_html($rec['confidence']); ?>٪ سفارشات مشترک
                            </span>
                            <strong class="fws-item-name"><?php echo esc_html($rec['name']); ?></strong>
                            <span class="fws-item-price"><?php echo wc_price($rec['price']); ?></span>
                        </div>
                    </div>
                    <?php if ($idx < count($recommendations) - 1): ?>
                        <div class="fws-plus-sign">+</div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <!-- Bundle Action Bar -->
            <div class="fws-bundle-action-bar">
                <div class="fws-pricing-breakdown">
                    <span class="fws-label">قیمت کل پکیج با تخفیف هوشمند (<?php echo esc_html(12); ?>٪):</span>
                    <div class="fws-prices">
                        <del class="fws-original-price"><?php echo wc_price($total_bundle_original); ?></del>
                        <strong class="fws-discounted-price"><?php echo wc_price($total_bundle_discounted); ?></strong>
                    </div>
                </div>
                <button type="button" class="fws-add-bundle-btn" data-main-id="<?php echo esc_attr($product->get_id()); ?>">
                    ⚡ افزودن پکیج هوشمند به سبد خرید
                </button>
            </div>
        </div>
        <?php
    }

    public function render_cart_recommendations_box() {
        if (!WC()->cart || WC()->cart->is_empty()) return;

        $cart_product_ids = array();
        foreach (WC()->cart->get_cart() as $item) {
            $cart_product_ids[] = absint($item['product_id']);
        }

        $engine = FWS_Prediction_Engine::get_instance();
        $recommendations = $engine->get_cart_recommendations($cart_product_ids, 3);

        if (empty($recommendations)) return;
        ?>
        <div class="fws-cart-recommendations-wrapper" dir="rtl">
            <h4 class="fws-cart-title">🛍️ مشتریانی که این سبد را خریدند، این کالاها را نیز تهیه کردند:</h4>
            <div class="fws-cart-grid">
                <?php foreach ($recommendations as $rec): ?>
                    <div class="fws-cart-item">
                        <img src="<?php echo esc_url($rec['image']); ?>" alt="<?php echo esc_attr($rec['name']); ?>" loading="lazy" decoding="async" width="56" height="56">
                        <div class="fws-cart-item-details">
                            <strong><?php echo esc_html($rec['name']); ?></strong>
                            <span class="fws-cart-item-price"><?php echo wc_price($rec['price']); ?></span>
                            <span class="fws-cart-confidence"><?php echo esc_html($rec['confidence']); ?>٪ همبستگی خرید</span>
                        </div>
                        <button type="button" class="fws-quick-add-btn" data-product-id="<?php echo esc_attr($rec['product_id']); ?>">+ افزودن به سبد</button>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Sales Booster 1: Post-Purchase 1-Click Upsell Box on Thank You Page
     */
    public function render_thank_you_upsell_box($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        // Security check: Only allow active/processing orders
        if (!in_array($order->get_status(), array('pending', 'on-hold', 'processing'))) {
            return;
        }

        $engine = FWS_Prediction_Engine::get_instance();
        $upsell = $engine->get_post_purchase_upsell($order_id);
        if (!$upsell) return;

        // Check if already claimed to prevent duplicate clicks
        if ($order->get_meta('_fws_upsell_added_' . $upsell['product_id'])) {
            return;
        }
        ?>
        <div class="fws-thankyou-upsell-box" dir="rtl">
            <div class="fws-thankyou-badge">⚡ پیشنهاد اختصاصی و آنی (بدون هزینه ارسال مجدد)</div>
            <h3 class="fws-thankyou-title">پیشنهاد مکمل بر اساس اقلام سفارش داده شده شما</h3>
            <p class="fws-thankyou-desc">
                به عنوان تشکر، می‌توانید محصول <strong>«<?php echo esc_html($upsell['name']); ?>»</strong> را با <strong><?php echo esc_html($upsell['discount_percent']); ?>٪ تخفیف اختصاصی</strong> تنها با یک کلیک به همین سفارش اضافه نمایید!
            </p>
            <div class="fws-thankyou-item-row">
                <img src="<?php echo esc_url($upsell['image']); ?>" alt="<?php echo esc_attr($upsell['name']); ?>" loading="lazy" decoding="async" width="64" height="64">
                <div class="fws-thankyou-pricing">
                    <del><?php echo wc_price($upsell['regular_price']); ?></del>
                    <strong><?php echo wc_price($upsell['discounted_price']); ?></strong>
                    <span class="fws-thankyou-tag"><?php echo esc_html($upsell['confidence']); ?>٪ همبستگی با سبد شما</span>
                </div>
                <button type="button" class="fws-thankyou-claim-btn" 
                        data-order-id="<?php echo esc_attr($order_id); ?>" 
                        data-order-key="<?php echo esc_attr($order->get_order_key()); ?>" 
                        data-product-id="<?php echo esc_attr($upsell['product_id']); ?>">
                    ✅ افزودن آنی به سفارش جاری
                </button>
            </div>
        </div>
        <?php
    }

    /**
     * Sales Booster 2: Dynamic Free Shipping Progress Bar with Smart Fillers
     */
    public function render_free_shipping_progress_bar() {
        if (!WC()->cart) return;

        $threshold = (float) 2000000;
        if ($threshold <= 0) return;

        $cart_total = (float) (WC()->cart ? WC()->cart->get_subtotal() : 0);
        $percentage = min(100, round(($cart_total / $threshold) * 100));
        $remaining = max(0, $threshold - $cart_total);

        $engine = FWS_Prediction_Engine::get_instance();
        $fillers = ($remaining > 0) ? $engine->get_free_shipping_fillers($cart_total, $threshold) : array();
        ?>
        <div class="fws-shipping-bar-wrapper" dir="rtl">
            <div class="fws-shipping-status">
                <?php if ($remaining <= 0): ?>
                    <span class="fws-shipping-success">🎉 تبریک! سفارش شما مشمول ارسال کاملاً رایگان شد!</span>
                <?php else: ?>
                    <span>تنها <strong><?php echo wc_price($remaining); ?></strong> تا <strong>ارسال کاملاً رایگان</strong> سفارش شما مانده!</span>
                <?php endif; ?>
                <span class="fws-shipping-percent"><?php echo esc_html($percentage); ?>٪</span>
            </div>
            <div class="fws-progress-track">
                <div class="fws-progress-fill" style="width: <?php echo esc_attr($percentage); ?>%;"></div>
            </div>

            <?php if (!empty($fillers)): ?>
                <div class="fws-fillers-row">
                    <span class="fws-fillers-title">کالاهای پیشنهادی متناسب با سبد برای رسیدن به سقف ارسال رایگان:</span>
                    <div class="fws-fillers-list">
                        <?php foreach ($fillers as $fil): ?>
                            <div class="fws-filler-card">
                                <img src="<?php echo esc_url($fil['image']); ?>" alt="<?php echo esc_attr($fil['name']); ?>" loading="lazy" decoding="async" width="48" height="48">
                                <div class="fws-filler-info">
                                    <span class="fws-filler-name"><?php echo esc_html($fil['name']); ?></span>
                                    <span class="fws-filler-price"><?php echo wc_price($fil['price']); ?></span>
                                </div>
                                <button type="button" class="fws-quick-add-btn" data-product-id="<?php echo esc_attr($fil['product_id']); ?>">+ افزودن</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Sales Booster 3: Exit-Intent Rescue Modal
     */
    public function render_exit_intent_rescue_modal() {
        if (!is_cart() && !is_checkout()) return;
        if (!WC()->cart || WC()->cart->is_empty()) return;
        ?>
        <div id="fws-exit-intent-modal" class="fws-modal" style="display:none;" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="fws-modal-title">
            <div class="fws-modal-content">
                <button type="button" class="fws-modal-close" aria-label="بستن">&times;</button>
                <div class="fws-modal-header">
                    <span class="fws-modal-badge">🔥 پیشنهاد خداحافظی</span>
                    <h3 id="fws-modal-title">آیا قبل از تکمیل سفارش قصد خروج دارید؟</h3>
                    <p>فقط برای ۱۰ دقیقه آینده، تخفیف شگفت‌انگیز سبد خرید روی اقلام انتخابی شما اعمال می‌شود!</p>
                </div>
                <div class="fws-modal-actions">
                    <a href="<?php echo wc_get_checkout_url(); ?>" class="fws-modal-confirm-btn">تکمیل خرید با تخفیف ویژه</a>
                    <button type="button" class="fws-modal-dismiss-btn">خیر، انصراف</button>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_my_account_prediction_widget() {
        if (!is_user_logged_in()) return;
        $user_id = get_current_user_id();
        $engine = FWS_Prediction_Engine::get_instance();
        $prediction = $engine->get_user_next_purchase_prediction($user_id);
        if ($prediction) {
            ?>
            <div class="fws-account-prediction-box" dir="rtl">
                <div class="fws-account-prediction-badge">✨ پیش‌بینی هوشمند سفارش بعدی شما</div>
                <h4 style="margin: 6px 0 12px; font-weight: 700; color: #1e293b;">کالای متناسب با سلیقه و سوابق خرید شما:</h4>
                <div class="fws-account-item">
                    <img src="<?php echo esc_url($prediction['image']); ?>" alt="<?php echo esc_attr($prediction['name']); ?>" loading="lazy" decoding="async" width="56" height="56">
                    <div class="fws-account-item-info">
                        <strong><?php echo esc_html($prediction['name']); ?></strong>
                        <span class="fws-account-item-price"><?php echo wc_price($prediction['price']); ?></span>
                        <span class="fws-account-item-conf"><?php echo esc_html($prediction['confidence']); ?>٪ احتمال علاقه‌مندی شما</span>
                    </div>
                    <button type="button" class="fws-quick-add-btn" data-product-id="<?php echo esc_attr($prediction['product_id']); ?>">+ افزودن سریع به سبد</button>
                </div>
            </div>
            <?php
        }
    }

    /**
     * شورت‌کد اختصاصی جهت نمایش پیشنهادهای کالا در هر بخش دلخواه قالب یا صفحه‌ساز
     * نحوه استفاده: [fws_predicted_products id="123" limit="3" title="کالاهای پیشنهادی"]
     */
    public function shortcode_handler($atts) {
        $atts = shortcode_atts(array(
            'id'    => 0,
            'limit' => 3,
            'title' => 'پیشنهادهای هوشمند دیتابیس (خریداری‌شده با این کالا)',
        ), $atts, 'fws_predicted_products');

        $product_id = absint($atts['id']);
        if ($product_id <= 0) {
            global $product;
            if ($product && is_a($product, 'WC_Product')) {
                $product_id = $product->get_id();
            }
        }

        if ($product_id <= 0) return '';

        $engine = FWS_Prediction_Engine::get_instance();
        $recommendations = $engine->get_recommendations_for_product($product_id, absint($atts['limit']));
        if (empty($recommendations)) return '';

        ob_start();
        ?>
        <div class="fws-cart-recommendations-wrapper fws-shortcode-wrapper" dir="rtl">
            <h4 class="fws-cart-title"><?php echo esc_html($atts['title']); ?></h4>
            <div class="fws-cart-grid">
                <?php foreach ($recommendations as $rec): ?>
                    <div class="fws-cart-item">
                        <img src="<?php echo esc_url($rec['image']); ?>" alt="<?php echo esc_attr($rec['name']); ?>" loading="lazy" decoding="async" width="56" height="56">
                        <div class="fws-cart-item-details">
                            <strong><?php echo esc_html($rec['name']); ?></strong>
                            <span class="fws-cart-item-price"><?php echo wc_price($rec['price']); ?></span>
                            <span class="fws-cart-confidence"><?php echo esc_html($rec['confidence']); ?>٪ تطابق سفارشات</span>
                        </div>
                        <button type="button" class="fws-quick-add-btn" data-product-id="<?php echo esc_attr($rec['product_id']); ?>">+ افزودن به سبد</button>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * شورت‌کد نمایش پکیج هوشمند کالا در هر صفحه یا تب دلخواه: [fws_bundle id="123"]
     */
    public function render_bundle_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => 0,
        ), $atts, 'fws_bundle');

        $product_id = absint($atts['id']);
        if ($product_id <= 0 && function_exists('is_product') && is_product()) {
            global $product;
            $product_id = ($product && is_a($product, 'WC_Product')) ? $product->get_id() : 0;
        }

        if ($product_id <= 0) return '';

        ob_start();
        $this->render_product_recommendations_box($product_id);
        return ob_get_clean();
    }

    /**
     * شورت‌کد نوار پیشرفت ارسال رایگان: [fws_free_shipping_bar]
     */
    public function render_free_shipping_shortcode($atts) {
        ob_start();
        $this->render_free_shipping_progress_bar();
        return ob_get_clean();
    }

    /**
     * شورت‌کد پیشنهادات متناسب با سبد خرید: [fws_cart_recommendations]
     */
    public function render_cart_recommendations_shortcode($atts) {
        ob_start();
        $this->render_cart_recommendations_box();
        return ob_get_clean();
    }

    /**
     * ارتقای هوشمند نتایج جستجو: تزریق پرفروش‌ترین کالای مکمل خریداری‌شده در کنار محصول جستجوشده به حلقه نتایج
     * مثال کاربر: خریدار لپ‌تاپ هنگام سرچ لپ‌تاپ، پرفروش‌ترین ماوس مکمل را بالاتر در نتایج مشاهده می‌کند
     */
    public function inject_complementary_into_search_results($posts, $query) {
        if (!is_search() || is_admin() || !$query->is_main_query()) {
            return $posts;
        }

        $search_query = get_search_query();
        if (empty($search_query) || empty($posts)) {
            return $posts;
        }

        $engine = FWS_Prediction_Engine::get_instance();
        $complements = $engine->get_search_co_occurrence_recommendations($search_query, 1);
        if (empty($complements)) {
            return $posts;
        }

        $complement_id = absint($complements[0]['product_id']);
        $existing_ids = wp_list_pluck($posts, 'ID');

        // اگر محصول مکمل در نتایج اولیه نیست، آن را در رتبه دوم یا اول نتایج تزریق کن
        if (!in_array($complement_id, $existing_ids, true)) {
            $complement_post = get_post($complement_id);
            if ($complement_post) {
                $complement_post->fws_is_search_boosted = true;
                $complement_post->fws_boost_reason = $complements[0]['reason'];
                array_splice($posts, 1, 0, array($complement_post));
            }
        }

        return $posts;
    }

    /**
     * رندر بنر هوشمند پیشنهاد کالای مکمل پرفروش در بالای لیست نتایج جستجو
     */
    public function render_search_complementary_banner() {
        if (!is_search()) return;

        $search_query = get_search_query();
        if (empty($search_query)) return;

        $engine = FWS_Prediction_Engine::get_instance();
        $complements = $engine->get_search_co_occurrence_recommendations($search_query, 2);
        if (empty($complements)) return;

        ?>
        <div class="fws-search-booster-banner" dir="rtl">
            <div class="fws-search-booster-header">
                <span class="fws-search-badge">🎯 پیشنهاد هوشمند خریداران قبلی</span>
                <h3 class="fws-search-title">خریداران «<?php echo esc_html($search_query); ?>» معمولاً این کالای مکمل را نیز خریده‌اند:</h3>
                <p class="fws-search-subtitle">بر اساس تحلیل داده‌کاوی سبدهای خرید، این محصول بیشترین نرخ خرید همزمان را داشته است.</p>
            </div>
            <div class="fws-search-items-row">
                <?php foreach ($complements as $item): ?>
                    <div class="fws-search-item-card">
                        <div class="fws-search-item-body">
                            <a href="<?php echo esc_url(get_permalink($item['product_id'])); ?>" class="fws-search-item-thumb">
                                <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['name']); ?>" loading="lazy" decoding="async" width="60" height="60">
                            </a>
                            <div class="fws-search-item-info">
                                <span class="fws-search-co-tag">🔥 <?php echo esc_html($item['confidence']); ?>٪ سفارش همزمان</span>
                                <a href="<?php echo esc_url(get_permalink($item['product_id'])); ?>" class="fws-search-name">
                                    <strong><?php echo esc_html($item['name']); ?></strong>
                                </a>
                                <span class="fws-search-reason"><?php echo esc_html($item['reason']); ?></span>
                                <div class="fws-search-action-bar">
                                    <span class="fws-search-price"><?php echo wc_price($item['price']); ?></span>
                                    <button type="button" class="fws-quick-add-btn" data-product-id="<?php echo esc_attr($item['product_id']); ?>">
                                        + افزودن فوری به سبد
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}
