<?php
/**
 * Class FWS_Admin_Page
 * پیشخوان مدیریتی و گزارش‌گیری الگوهای دیتابیس در ووکامرس
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWS_Admin_Page {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }

    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'پیش‌بینی و پیشنهاد هوشمند خرید',
            'پیش‌بینی هوشمند خرید',
            'manage_woocommerce',
            'fast-woo-predictive',
            array($this, 'render_admin_dashboard')
        );
    }

    public function render_admin_dashboard() {
        global $wpdb;
        $table = $wpdb->prefix . FWS_Database_Miner::TABLE_AFFINITY;
        $total_rules = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        $admin_nonce = wp_create_nonce('fws_admin_nonce');
        ?>
        <div class="wrap" dir="rtl">
            <h1>سیستم پیش‌بینی و پیشنهاد هوشمند خرید (مبتنی بر دیتابیس سفارشات)</h1>
            <p>این افزونه با آنالیز جداول سفارشات ووکامرس، بدون ایجاد بار اضافی روی سرور، پیوندهای قوی بین خرید کالاها را شناسایی و پیشنهاد می‌دهد.</p>
            
            <div class="card" style="max-width: 650px; margin-top: 20px; padding: 20px;">
                <h2>📊 وضعیت موتور و کش ماتریس همبستگی</h2>
                <table class="widefat striped" style="margin-top: 15px; margin-bottom: 20px;">
                    <tbody>
                        <tr>
                            <td><strong>قوانین همبستگی فعال در کش دیتابیس:</strong></td>
                            <td><span style="color:#059669; font-weight:bold;"><?php echo number_format_i18n($total_rules); ?> رابطه معتبر</span></td>
                        </tr>
                        <tr>
                            <td><strong>حداقل ضریب اطمینان (Confidence):</strong></td>
                            <td><?php echo esc_html(60); ?>٪</td>
                        </tr>
                        <tr>
                            <td><strong>بازه تحلیل سفارشات تاریخی:</strong></td>
                            <td><?php echo esc_html(90); ?> روز اخیر</td>
                        </tr>
                        <tr>
                            <td><strong>وضعیت بهینه‌سازی دیتابیس:</strong></td>
                            <td>ایندکس‌های پوششی فعال (Covering Indexes) - صفر کندی در صفحات</td>
                        </tr>
                    </tbody>
                </table>

                <div style="display: flex; gap: 10px; align-items: center;">
                    <button class="button button-primary" id="fws-recalculate-btn">🔄 تحلیل مجدد دیتابیس سفارشات</button>
                    <button class="button button-secondary" id="fws-optimize-db-btn">⚡ بهینه‌سازی ایندکس‌ها و پاکسازی کش</button>
                    <span id="fws-admin-status" style="margin-right: 15px; font-weight: bold;"></span>
                </div>
            </div>

            <script>
            jQuery(document).ready(function($) {
                var nonce = '<?php echo esc_js($admin_nonce); ?>';
                
                $('#fws-recalculate-btn').on('click', function(e) {
                    e.preventDefault();
                    var $btn = $(this);
                    $btn.prop('disabled', true).text('در حال پردازش سفارشات...');
                    $('#fws-admin-status').text('در حال اجرای الگوریتم Apriori به صورت دسته‌ای...').css('color', '#2563eb');

                    $.post(ajaxurl, {
                        action: 'fws_recalculate_rules',
                        nonce: nonce
                    }, function(res) {
                        $btn.prop('disabled', false).text('🔄 تحلیل مجدد دیتابیس سفارشات');
                        if (res.success) {
                            $('#fws-admin-status').text('✓ موفقیت: ' + res.data.rules_count + ' رابطه کشف و ذخیره شد.').css('color', '#059669');
                            setTimeout(function(){ location.reload(); }, 1200);
                        } else {
                            $('#fws-admin-status').text('خطا: ' + (res.data ? res.data.message : 'نامشخص')).css('color', '#dc2626');
                        }
                    }).fail(function() {
                        $btn.prop('disabled', false).text('🔄 تحلیل مجدد دیتابیس سفارشات');
                        $('#fws-admin-status').text('خطای سرور در انجام تحلیل. لطفاً گزارش خطای PHP را بررسی نمایید.').css('color', '#dc2626');
                    });
                });

                $('#fws-optimize-db-btn').on('click', function(e) {
                    e.preventDefault();
                    var $btn = $(this);
                    $btn.prop('disabled', true).text('در حال بهینه‌سازی...');
                    
                    $.post(ajaxurl, {
                        action: 'fws_optimize_database',
                        nonce: nonce
                    }, function(res) {
                        $btn.prop('disabled', false).text('⚡ بهینه‌سازی ایندکس‌ها و پاکسازی کش');
                        if (res.success) {
                            $('#fws-admin-status').text('✓ ایندکس‌ها مرتب و کش با موفقیت پاکسازی شد.').css('color', '#059669');
                        }
                    }).fail(function() {
                        $btn.prop('disabled', false).text('⚡ بهینه‌سازی ایندکس‌ها و پاکسازی کش');
                        $('#fws-admin-status').text('خطا در پاکسازی کش یا بهینه‌سازی جدول.').css('color', '#dc2626');
                    });
                });
            });
            </script>
        </div>
        <?php
    }
}
