<?php
/**
 * Class FWS_Ajax_Handler
 * پردازشگر امن و فوق‌سریع AJAX (حفاظت صددرصدی در برابر IDOR، اعتبارسنجی نانس، محافظت از انبار و ثبت تخفیف‌های هوشمند)
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWS_Ajax_Handler {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('wp_ajax_fws_add_bundle', array($this, 'add_bundle_to_cart'));
        add_action('wp_ajax_nopriv_fws_add_bundle', array($this, 'add_bundle_to_cart'));

        add_action('wp_ajax_fws_add_single', array($this, 'add_single_to_cart'));
        add_action('wp_ajax_nopriv_fws_add_single', array($this, 'add_single_to_cart'));

        add_action('wp_ajax_fws_thankyou_upsell', array($this, 'process_thankyou_upsell'));
        add_action('wp_ajax_nopriv_fws_thankyou_upsell', array($this, 'process_thankyou_upsell'));

        add_action('wp_ajax_fws_recalculate_rules', array($this, 'recalculate_rules'));
        add_action('wp_ajax_fws_optimize_database', array($this, 'optimize_database'));
    }

    /**
     * بررسی سقف نرخ مجاز درخواست‌ها (Rate Limiting) جهت حفاظت در برابر ربات‌ها، حملات DoS و Cart Stuffing
     */
    private function check_rate_limit($action = 'cart_action', $limit = 30, $window = 60) {
        $ip = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1';
        $key = 'fws_rate_' . md5($action . '_' . $ip);
        $attempts = (int) get_transient($key);
        if ($attempts >= $limit) {
            wp_send_json_error(array('message' => 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کرده و سپس تلاش نمایید.'));
        }
        set_transient($key, $attempts + 1, $window);
    }

    /**
     * افزودن دسته‌ای اقلام پکیج و تنظیم سشن تخفیف
     */
    public function add_bundle_to_cart() {
        check_ajax_referer('fws_prediction_nonce', 'nonce');
        $this->check_rate_limit('add_bundle', 25, 60);

        $raw_ids = isset($_POST['product_ids']) ? (array) $_POST['product_ids'] : array();
        $product_ids = array_filter(array_unique(array_map('absint', $raw_ids)));

        if (empty($product_ids)) {
            wp_send_json_error(array('message' => 'هیچ محصول معتبری انتخاب نشده است.'));
        }

        // Cap maximum bundle items per request to prevent payload flooding
        if (count($product_ids) > 10) {
            $product_ids = array_slice($product_ids, 0, 10);
        }

        // Ensure customer session is created and persisted for guest users
        if (WC()->session && !WC()->session->has_session()) {
            WC()->session->set_customer_session_cookie(true);
        }

        // Store bundle product ids in session for dynamic cart discount calculations
        if (WC()->session) {
            $existing = (array) WC()->session->get('fws_bundle_items', array());
            $merged = array_unique(array_merge($existing, $product_ids));
            WC()->session->set('fws_bundle_items', $merged);
        }

        $added = 0;
        foreach ($product_ids as $pid) {
            $product = wc_get_product($pid);
            if ($product && $product->is_purchasable() && $product->is_in_stock()) {
                $cart_item_key = WC()->cart->add_to_cart($pid, 1);
                if ($cart_item_key) {
                    $added++;
                }
            }
        }

        if ($added === 0) {
            $notices = wc_get_notices('error');
            $notice_msg = !empty($notices) ? wp_strip_all_tags(reset($notices)['notice']) : 'محصولات انتخابی در انبار موجود یا قابل سفارش نیستند.';
            wc_clear_notices();
            wp_send_json_error(array('message' => $notice_msg));
        }

        ob_start();
        woocommerce_mini_cart();
        $mini_cart = ob_get_clean();

        wp_send_json_success(array(
            'message'    => "{$added} محصول با تخفیف پکیج به سبد خرید افزوده شد.",
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_url'   => wc_get_cart_url(),
            'cart_hash'  => WC()->cart->get_cart_hash(),
            'fragments'  => apply_filters('woocommerce_add_to_cart_fragments', array(
                'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
            )),
        ));
    }

    /**
     * افزودن سریع کالای پرکننده یا پیشنهادی
     */
    public function add_single_to_cart() {
        check_ajax_referer('fws_prediction_nonce', 'nonce');
        $this->check_rate_limit('add_single', 30, 60);

        $pid = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        if ($pid > 0) {
            $product = wc_get_product($pid);
            if ($product && $product->is_purchasable() && $product->is_in_stock()) {
                if (WC()->session && !WC()->session->has_session()) {
                    WC()->session->set_customer_session_cookie(true);
                }
                $cart_item_key = WC()->cart->add_to_cart($pid, 1);
                if ($cart_item_key) {
                    ob_start();
                    woocommerce_mini_cart();
                    $mini_cart = ob_get_clean();

                    wp_send_json_success(array(
                        'message'    => 'محصول با موفقیت به سبد افزوده شد.',
                        'cart_count' => WC()->cart->get_cart_contents_count(),
                        'cart_url'   => wc_get_cart_url(),
                        'cart_hash'  => WC()->cart->get_cart_hash(),
                        'fragments'  => apply_filters('woocommerce_add_to_cart_fragments', array(
                            'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
                        )),
                    ));
                } else {
                    $notices = wc_get_notices('error');
                    $notice_msg = !empty($notices) ? wp_strip_all_tags(reset($notices)['notice']) : 'امکان افزودن این کالا به سبد خرید وجود ندارد.';
                    wc_clear_notices();
                    wp_send_json_error(array('message' => $notice_msg));
                }
            } else {
                wp_send_json_error(array('message' => 'این کالا در حال حاضر موجود یا قابل سفارش نیست.'));
            }
        }
        wp_send_json_error(array('message' => 'شناسه محصول نامعتبر است.'));
    }

    /**
     * افزودن ۱ کلیکی آپسل به سفارش جاری (محافظت کامل از IDOR و جلوگیری از ثبت تکراری)
     */
    public function process_thankyou_upsell() {
        check_ajax_referer('fws_prediction_nonce', 'nonce');
        $this->check_rate_limit('thankyou_upsell', 10, 60);

        $order_id   = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $order_key  = isset($_POST['order_key']) ? sanitize_text_field(wp_unslash($_POST['order_key'])) : '';
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;

        $order   = wc_get_order($order_id);
        $product = wc_get_product($product_id);

        if (!$order || !$product) {
            wp_send_json_error(array('message' => 'اطلاعات سفارش یا کالا نامعتبر است.'));
        }

        // Strict Anti-IDOR Authorization Check: Verify either authenticated customer ID or cryptographic Order Key
        $current_user_id = get_current_user_id();
        $is_owner  = ($current_user_id > 0 && $order->get_user_id() === $current_user_id);
        $valid_key = (!empty($order_key) && hash_equals($order->get_order_key(), $order_key));

        if (!$is_owner && !$valid_key && !current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'خطای امنیتی: دسترسی غیرمجاز به این سفارش.'));
        }

        // Only allow modification for orders in modifiable status
        if (!in_array($order->get_status(), array('pending', 'on-hold', 'processing'))) {
            wp_send_json_error(array('message' => 'امکان تغییر سفارش با وضعیت فعلی آن وجود ندارد.'));
        }

        // Idempotency: Prevent duplicate addition via order meta and existing order items
        $meta_flag = '_fws_upsell_added_' . $product_id;
        if ($order->get_meta($meta_flag)) {
            wp_send_json_error(array('message' => 'این محصول قبلاً به سفارش شما افزوده شده است.'));
        }
        foreach ($order->get_items() as $existing_item) {
            if ($existing_item->get_product_id() === $product_id || $existing_item->get_variation_id() === $product_id) {
                wp_send_json_error(array('message' => 'این محصول قبلاً در این سفارش ثبت شده است.'));
            }
        }

        // Stock & purchasable verification
        if (!$product->is_purchasable() || !$product->is_in_stock()) {
            wp_send_json_error(array('message' => 'متأسفانه موجودی این کالا در انبار به اتمام رسیده است.'));
        }

        // Calculate discounted price
        $discount_pct = max(0, min(90, floatval(20)));
        $regular_price = (float) $product->get_price();
        $discounted_price = round($regular_price * ((100 - $discount_pct) / 100), wc_get_price_decimals());

        $item_id = $order->add_product($product, 1, array(
            'subtotal' => $discounted_price,
            'total'    => $discounted_price,
        ));

        if (!$item_id) {
            wp_send_json_error(array('message' => 'خطا در الحاق محصول به سفارش. لطفاً مجدداً تلاش کنید.'));
        }

        // Mark as added and record customer note
        $order->update_meta_data($meta_flag, current_time('mysql'));
        $order->calculate_totals();
        $order->add_order_note(sprintf(
            'محصول مکمل «%s» با %s٪ تخفیف اختصاصی (%s) از طریق سیستم پیشنهاد هوشمند به سفارش افزوده شد.',
            $product->get_name(),
            $discount_pct,
            wc_price($discounted_price)
        ));
        $order->save();

        wp_send_json_success(array(
            'message'   => 'کالای مکمل با موفقیت و با تخفیف ویژه به سفارش شما اضافه شد!',
            'new_total' => $order->get_formatted_order_total(),
        ));
    }

    /**
     * بازسازی الگوها با احراز هویت ادمین
     */
    public function recalculate_rules() {
        check_ajax_referer('fws_admin_nonce', 'nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'عدم دسترسی مجاز.'));
        }

        if (get_transient('fws_mining_lock')) {
            wp_send_json_error(array('message' => 'عملیات تحلیل داده‌ها هم‌اکنون در پس‌زمینه در حال اجرا است. لطفاً شکیبا باشید.'));
        }

        $count = FWS_Database_Miner::run_market_basket_analysis(90);
        wp_send_json_success(array('rules_count' => $count));
    }

    /**
     * بهینه‌سازی دیتابیس با احراز هویت ادمین
     */
    public function optimize_database() {
        check_ajax_referer('fws_admin_nonce', 'nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'عدم دسترسی مجاز.'));
        }

        FWS_Performance_Optimizer::optimize_database_tables();
        wp_send_json_success(array('message' => 'جداول با موفقیت Defragment، ایندکس‌ها بهینه‌سازی و ترنزینت‌های منقضی پاکسازی شدند.'));
    }
}
